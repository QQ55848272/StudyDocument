import request from '@/utils/request'

export function listTaskAlarm(query) {
    return request({
        url: '/hdsp/taskAlarm/list',
        method: 'get',
        params: query,
    })
}

export function addTaskAlarm(data) {
    return request({
        url: '/hdsp/taskAlarm/add',
        method: 'post',
        data: data,
    })
}

export function queryLogs(query) {
    return request({
        url: '/hdsp/logs/query',
        method: 'get',
        params: query,
    })
}


export function queryEmployer(query) {
    return request({
        url: '/hdsp/employer/query',
        method: 'get',
        params: query,
    })
}