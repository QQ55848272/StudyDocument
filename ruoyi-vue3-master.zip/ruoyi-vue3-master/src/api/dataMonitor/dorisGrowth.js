import request from '@/utils/request'

export function listDorisGrowth(query) {
    return request({
        url: '/doris/dorisGrowth/list',
        method: 'get',
        params: query,
    })
}