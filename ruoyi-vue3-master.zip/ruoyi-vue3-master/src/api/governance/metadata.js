import request from '@/utils/request';  // 引入若依框架的 request 工具（封装了 Axios）

// 获取 Doris 数据表列表
export function getDorisTableList(query) {
    return request({
        url: '/metadata/list',  // 请求 URL
        method: 'get',
        params: query  // 请求的查询参数
    });
}

// 获取所有 schema（用于下拉框）
export function getSchemas() {
    return request({
        url: '/metadata/table_schemas',
        method: 'get'
    })
}

// 获取表列表（带筛选参数）
export function getTableList(tableSchema, tableName, tableComment) {
    return request({
        url: '/metadata/tableList',
        method: 'get',
        params: { tableSchema, tableName, tableComment}
    })
}

// 获取字段元数据
export function getColumnList(tableSchema, tableName) {
    return request({
        url: '/metadata/columnList',
        method: 'get',
        params: { tableSchema, tableName }
    })
}

// 获取表元数据
export function getTableMetadata(tableSchema, tableName) {
    return request({
        url: '/metadata/list',
        method: 'get',
        params: { tableSchema, tableName }
    })
}
