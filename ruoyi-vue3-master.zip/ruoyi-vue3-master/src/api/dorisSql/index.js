import request from '@/utils/request'

export function listSlowSql(query) {
    return request({
        url: '/doris/slowSql/list',
        method: 'get',
        params: query,
    })
}

export function detailsSlowSql(query) {
    return request({
        url: '/doris/slowSql/details',
        method: 'get',
        params: query,
    })
}


export function dorisUser() {
    return request({
        url: '/doris/user/list',
        method: 'get',
    })
}