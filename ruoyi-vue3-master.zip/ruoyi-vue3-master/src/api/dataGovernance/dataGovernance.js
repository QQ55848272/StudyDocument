import request from '@/utils/request'

// 查询schema下包含信息列表
export function listDataGovernance(query) {
  return request({
    url: '/dataGovernance/dataGovernance/list',
    method: 'get',
    params: query
  })
}

// 查询schema下包含信息详细
export function getDataGovernance(id) {
  return request({
    url: '/dataGovernance/dataGovernance/' + id,
    method: 'get'
  })
}

// 新增schema下包含信息
export function addDataGovernance(data) {
  return request({
    url: '/dataGovernance/dataGovernance',
    method: 'post',
    data: data
  })
}

// 修改schema下包含信息
export function updateDataGovernance(data) {
  return request({
    url: '/dataGovernance/dataGovernance',
    method: 'put',
    data: data
  })
}

// 删除schema下包含信息
export function delDataGovernance(id) {
  return request({
    url: '/dataGovernance/dataGovernance/' + id,
    method: 'delete'
  })
}
