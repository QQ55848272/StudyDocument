import request from '@/utils/request'

export function queryPdfList(query) {
    return request({
        url: '/files/list',
        method: 'get',
        params: query
    })
}