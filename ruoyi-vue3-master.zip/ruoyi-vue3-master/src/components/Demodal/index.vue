<template>
  <div class="de-modal">
    <el-dialog
      :fullscreen="fullScreen"
      :model-value="visible"
      @update:model-value="$emit('update:visible', $event)"
      :width="width"
      :close-on-click-modal="maskClosable"
      :mask="mask"
      :close-on-press-escape="keyboard"
      align-center
      @before-close="beforeClose"
      @close="handleCancel"
    >
      <template #header="{ close, titleId, titleClass }">
        <div class="my-header">
          <div :class="titleClass">{{ title }}</div>
          <div class="cp">
            <svg-icon
              color="#666"
              hoverColor="#409EFF"
              :icon-class="isLarge ? 'exit-fullscreen' : 'fullscreen'"
              @click="toggleLarge"
            />
          </div>
        </div>
      </template>
      <template #default>
        <slot></slot>
      </template>
      <template #footer>
        <div class="dialog-footer" v-show="showFooter">
          <el-button type="primary" @click="handleOk">{{ okText }}</el-button>
          <el-button @click="handleCancel">{{ cancelText }}</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed } from "vue";

const props = defineProps({
  title: {
    type: String,
    default: "",
  },
  isFullScreen: {
    type: Boolean,
    default: false,
  },
  maskClosable: {
    type: Boolean,
    default: true,
  },
  keyboard: {
    type: Boolean,
    default: true,
  },
  closable: {
    type: Boolean,
    default: true,
  },
  mask: {
    type: Boolean,
    default: true,
  },
  width: {
    type: String,
    default: "800px",
  },
  okText: {
    type: String,
    default: "确 定",
  },
  cancelText: {
    type: String,
    default: "取 消",
  },
  visible: {
    type: Boolean,
    default: false,
  },

  showFooter: {
    type: Boolean,
    default: true,
  },
});

const isLarge = ref(props.isFullScreen);
const fullScreen = computed(() => isLarge.value);
const emit = defineEmits([
  "ok",
  "cancel",
  "update:isFullScreen",
  "update:visible",
]);

watch(
  () => props.visible,
  (newVal) => {
    if (!newVal && isLarge.value) {
      resetFullscreenState();
    }
  }
);

const handleOk = () => {
  emit("ok");
};

const handleCancel = () => {
  emit("cancel");
};

const resetFullscreenState = () => {
  isLarge.value = false;
  emit("update:isFullScreen", false);
};

const beforeClose = (done) => {
  if (!props.closable) return;

  // 关闭前强制恢复尺寸
  if (isLarge.value) {
    resetFullscreenState();
  }
  emit("cancel");
  done();
};

const toggleLarge = () => {
  isLarge.value = !isLarge.value;
  emit("update:isFullScreen", isLarge.value);
};
</script>

<style lang="scss" scoped>
.de-modal {
  .my-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-right: 20px;
    margin-top: -2px;
    font-family: PingFangSC, PingFang SC;
    font-weight: 600;
    font-size: 16px;
    color: #1f2e4d;
    .cp {
      cursor: pointer;
    }
  }

  :deep(.el-dialog:not(.is-fullscreen)) {
    margin-top: auto !important;
  }
}

:deep(.el-dialog__body) {
  overflow-y: auto;
  padding: 30px 24px 16px 24px;
}
</style>
