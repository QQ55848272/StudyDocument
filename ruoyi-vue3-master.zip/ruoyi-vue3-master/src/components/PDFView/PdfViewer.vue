<template>
  <el-dialog
    v-model="visible"
    :title="title"
    width="80%"
    top="5vh"
    :close-on-click-modal="false"
    @closed="handleDialogClosed"
  >
    <!-- 头部控制栏 -->
    <div class="pdf-preview-header" v-if="pdfDoc && !loading">
      <div class="page-controls">
        <el-button-group>
          <el-button
            :disabled="currentPage <= 1"
            @click="goToPreviousPage"
            size="small"
          >
            上一页
          </el-button>
          <el-button
            :disabled="currentPage >= totalPages"
            @click="goToNextPage"
            size="small"
          >
            下一页
          </el-button>
        </el-button-group>

        <div class="page-navigation">
          <span class="page-info">
            第 {{ currentPage }} 页 / 共 {{ totalPages }} 页
          </span>
          <el-input-number
            v-model="currentPage"
            :min="1"
            :max="totalPages"
            size="small"
            controls-position="right"
            @change="goToPage"
            style="width: 100px; margin: 0 8px"
          />
        </div>
      </div>

      <div class="zoom-controls">
        <el-button-group>
          <el-button
            :disabled="scale <= minScale"
            @click="zoomOut"
            size="small"
          >
            -
          </el-button>
          <el-button @click="resetZoom" size="small">
            {{ Math.round(scale * 100) }}%
          </el-button>
          <el-button :disabled="scale >= maxScale" @click="zoomIn" size="small">
            +
          </el-button>
        </el-button-group>
      </div>
    </div>

    <!-- 加载状态 -->
    <div class="pdf-loading" v-if="loading">
      <el-icon class="is-loading"><Loading /></el-icon>
      <span>{{ loadText }}</span>
    </div>

    <!-- 错误状态 -->
    <div class="pdf-error" v-else-if="error">
      <el-icon><CircleClose /></el-icon>
      <span>{{ error }}</span>
      <el-button
        @click="loadPdf"
        type="primary"
        size="small"
        style="margin-left: 10px"
      >
        重试
      </el-button>
    </div>

    <!-- PDF容器 -->
    <div
      ref="pdfContainer"
      class="pdf-container"
      :class="{
        'pdf-container-loading': loading,
        'pdf-container-error': error,
      }"
    >
      <!-- Canvas将通过JS动态插入 -->
    </div>
  </el-dialog>
</template>

<script setup>
import { ref, onMounted, watch, nextTick, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Loading, CircleClose } from '@element-plus/icons-vue'

// PDF.js 变量
let pdfjsLib = null

const loadPdfJs = async () => {
  if (typeof window !== 'undefined') {
    try {
      // 检查是否已加载
      if (window.pdfjsLib) {
        pdfjsLib = window.pdfjsLib
        return true
      }

      // 动态加载 PDF.js
      await new Promise((resolve, reject) => {
        const script = document.createElement('script')
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'
        script.onload = () => {
          pdfjsLib = window.pdfjsLib
          // 设置 worker
          pdfjsLib.GlobalWorkerOptions.workerSrc = 
            'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'
          resolve()
        }
        script.onerror = () => reject(new Error('PDF.js 脚本加载失败'))
        document.head.appendChild(script)
      })
      
      return true
    } catch (err) {
      console.error('PDF.js 加载失败:', err)
      throw new Error('PDF 渲染引擎加载失败')
    }
  }
  return false
}

const props = defineProps({
  url: {
    type: String,
    default: ''
  },
  modelValue: {
    type: Boolean,
    required: true
  },
  title: {
    type: String,
    default: 'PDF 预览'
  }
})

const emit = defineEmits(['update:modelValue'])

// 响应式数据
const visible = ref(props.modelValue)
const pdfContainer = ref(null)
const pdfDoc = ref(null)
const currentPage = ref(1)
const totalPages = ref(0)
const scale = ref(1.5)
const loading = ref(false)
const error = ref('')
const loadText = ref('正在加载PDF...')
const minScale = ref(0.5)
const maxScale = ref(3)
const currentUrl = ref(props.url)

// 监听器
watch(() => props.modelValue, async (val) => {
  visible.value = val
  if (val && currentUrl.value) {
    await nextTick()
    await loadPdf(currentUrl.value)
  }
})

watch(visible, val => {
  emit('update:modelValue', val)
  if (!val) {
    cleanup()
  }
})

watch(() => props.url, (newUrl) => {
  currentUrl.value = newUrl
})

// 改进的PDF加载方法
const loadPdf = async (url = '') => {
  const targetUrl = url || currentUrl.value
  
  if (!targetUrl) {
    error.value = 'PDF地址不能为空'
    return false
  }

  // 验证URL格式
  try {
    new URL(targetUrl)
  } catch {
    error.value = '无效的URL格式'
    return false
  }

  loading.value = true
  error.value = ''
  loadText.value = '正在初始化PDF查看器...'
  
  try {
    // 确保PDF.js已加载
    if (!pdfjsLib) {
      loadText.value = '正在加载PDF渲染引擎...'
      await loadPdfJs()
    }
    
    // 清空容器
    if (pdfContainer.value) {
      pdfContainer.value.innerHTML = ''
    }
    
    loadText.value = '正在连接PDF文档...'
    
    // 使用更兼容的配置
    const loadingTask = pdfjsLib.getDocument({
      url: targetUrl,
      withCredentials: false,
      // 禁用范围加载，可能有助于某些服务器
      disableRange: true,
      // 禁用流式加载
      disableStream: true,
      // 禁用自动获取
      disableAutoFetch: true,
    })
    
    // 添加进度监听
    loadingTask.onProgress = (progress) => {
      if (progress.total > 0) {
        const percent = Math.round((progress.loaded / progress.total) * 100)
        loadText.value = `正在加载PDF文档... ${percent}%`
      }
    }
    
    pdfDoc.value = await loadingTask.promise
    
    totalPages.value = pdfDoc.value.numPages
    currentPage.value = 1
    
    loadText.value = '正在渲染页面...'
    await renderCurrentPage()
    
    currentUrl.value = targetUrl
    ElMessage.success('PDF加载成功')
    return true
    
  } catch (err) {
    console.error('PDF加载失败:', err)
    
    let errorMessage = 'PDF加载失败'
    
    // 详细的错误分类
    switch (err.name) {
      case 'InvalidPDFException':
        errorMessage = '无效的PDF文件格式。文件可能已损坏或不是有效的PDF文件。'
        break
      case 'MissingPDFException':
        errorMessage = '找不到PDF文件。请检查文件地址是否正确。'
        break
      case 'UnexpectedResponseException':
        errorMessage = '服务器返回了意外的响应。可能是文件不存在或服务器错误。'
        break
      default:
        if (err.message.includes('NetworkError') || err.message.includes('Failed to fetch')) {
          errorMessage = '网络连接错误。请检查：1) 网络连接 2) 文件地址可访问性 3) 跨域限制'
        } else {
          errorMessage = err.message || 'PDF加载失败'
        }
    }
    
    error.value = errorMessage
    ElMessage.error(errorMessage)
    return false
  } finally {
    loading.value = false
  }
}

// 修复的页面渲染方法
const renderCurrentPage = async () => {
  if (!pdfDoc.value || !pdfjsLib) {
    error.value = 'PDF文档未加载'
    return
  }
  
  try {
    const page = await pdfDoc.value.getPage(currentPage.value)
    const viewport = page.getViewport({ scale: scale.value })
    
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('2d')
    
    if (!context) {
      throw new Error('无法获取Canvas渲染上下文')
    }
    
    // 设置Canvas尺寸
    canvas.height = viewport.height
    canvas.width = viewport.width
    
    // 设置Canvas样式
    canvas.style.display = 'block'
    canvas.style.margin = '10px auto'
    canvas.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)'
    canvas.style.maxWidth = '100%'
    canvas.style.border = '1px solid #e8e8e8'
    
    // 清空容器并添加Canvas
    if (pdfContainer.value) {
      pdfContainer.value.innerHTML = ''
      pdfContainer.value.appendChild(canvas)
    }
    
    // 创建渲染上下文
    const renderContext = {
      canvasContext: context,
      viewport: viewport
    }
    
    // 渲染页面
    await page.render(renderContext).promise
    
    // 清除错误状态
    error.value = ''
    
  } catch (err) {
    console.error('页面渲染失败:', err)
    
    let errorMessage = '页面渲染失败'
    if (err.message.includes('Canvas context')) {
      errorMessage = '浏览器不支持Canvas渲染，请更新浏览器或使用其他浏览器'
    } else if (err.message.includes('getPage')) {
      errorMessage = `无法获取第${currentPage.value}页，页面可能不存在`
    }
    
    error.value = errorMessage
    ElMessage.error(errorMessage)
    
    // 在容器中显示错误信息
    if (pdfContainer.value) {
      pdfContainer.value.innerHTML = `
        <div class="pdf-page-error">
          <div style="color: #f56c6c; text-align: center; padding: 40px;">
            <el-icon size="32"><CircleClose /></el-icon>
            <div style="margin-top: 16px;">${errorMessage}</div>
            <el-button 
              @click="renderCurrentPage" 
              type="primary" 
              size="small" 
              style="margin-top: 16px;"
            >
              重试渲染
            </el-button>
          </div>
        </div>
      `
      
      // 重新绑定点击事件
      const retryButton = pdfContainer.value.querySelector('button')
      if (retryButton) {
        retryButton.onclick = renderCurrentPage
      }
    }
  }
}

// 页面导航方法
const goToPage = (page) => {
  const targetPage = Math.max(1, Math.min(page, totalPages.value))
  if (targetPage !== currentPage.value) {
    currentPage.value = targetPage
    renderCurrentPage()
  }
}

const goToPreviousPage = () => goToPage(currentPage.value - 1)
const goToNextPage = () => goToPage(currentPage.value + 1)

// 缩放控制
const zoomIn = () => {
  if (scale.value < maxScale.value) {
    scale.value = Math.min(scale.value + 0.1, maxScale.value)
    renderCurrentPage()
  }
}

const zoomOut = () => {
  if (scale.value > minScale.value) {
    scale.value = Math.max(scale.value - 0.1, minScale.value)
    renderCurrentPage()
  }
}

const resetZoom = () => {
  scale.value = 1.5
  renderCurrentPage()
}

// 清理资源
const cleanup = () => {
  if (pdfDoc.value) {
    try {
      pdfDoc.value.destroy().catch(() => {})
    } catch (e) {
      // 忽略销毁错误
    }
    pdfDoc.value = null
  }
  currentPage.value = 1
  totalPages.value = 0
  scale.value = 1.5
  error.value = ''
  
  if (pdfContainer.value) {
    pdfContainer.value.innerHTML = ''
  }
}

const handleDialogClosed = () => {
  cleanup()
}

// 键盘事件
const handleKeydown = (event) => {
  if (!visible.value) return
  
  switch(event.key) {
    case 'ArrowLeft':
      event.preventDefault()
      goToPreviousPage()
      break
    case 'ArrowRight':
      event.preventDefault()
      goToNextPage()
      break
    case '+':
    case '=':
      event.preventDefault()
      zoomIn()
      break
    case '-':
      event.preventDefault()
      zoomOut()
      break
    case '0':
      event.preventDefault()
      resetZoom()
      break
  }
}

onMounted(() => {
  document.addEventListener('keydown', handleKeydown)
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeydown)
  cleanup()
})

defineExpose({
  loadPdf,
  goToPage,
  goToPreviousPage,
  goToNextPage,
  zoomIn,
  zoomOut,
  resetZoom,
  show: () => { visible.value = true },
  hide: () => { visible.value = false },
  cleanup
})
</script>

<style scoped>
.pdf-preview-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding: 8px 0;
  border-bottom: 1px solid #e8e8e8;
  flex-wrap: wrap;
  gap: 10px;
}

.page-controls,
.zoom-controls {
  display: flex;
  align-items: center;
  gap: 8px;
}

.page-info {
  margin: 0 8px;
  font-size: 14px;
  color: #606266;
  min-width: 100px;
  text-align: center;
}

.pdf-container {
  max-height: 70vh;
  overflow-y: auto;
  text-align: center;
  min-height: 200px;
  position: relative;
}

.pdf-loading,
.pdf-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #909399;
  gap: 16px;
}

.pdf-loading .el-icon,
.pdf-error .el-icon {
  font-size: 32px;
}

.pdf-error {
  color: #f56c6c;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
}

.pdf-page-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 300px;
  color: #f56c6c;
}

@media (max-width: 768px) {
  .pdf-preview-header {
    flex-direction: column;
    gap: 12px;
  }

  .page-controls,
  .zoom-controls {
    justify-content: center;
  }
}
</style>