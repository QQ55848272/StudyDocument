<template>
  <el-dialog v-model="visible" title="PDF 预览" width="80%" top="5vh">
    <div ref="pdfContainer" class="pdf-container"></div>
  </el-dialog>
</template>

<script setup>
import {ref, onMounted, watch} from 'vue'
// import * as pdfjsLib from 'pdfjs-dist'
import * as pdfjsLib from 'pdfjs-dist/build/pdf'
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker?worker'

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker

const props = defineProps({
  url: {
    type: String,
    required: true
  },
  modelValue: {
    type: Boolean,
    required: true
  }
})
const emit = defineEmits(['update:modelValue'])

const visible = ref(props.modelValue)
watch(() => props.modelValue, val => (visible.value = val))
watch(visible, val => emit('update:modelValue', val))

const pdfContainer = ref(null)

const renderPage = async (page, scale = 1.5) => {
  const viewport = page.getViewport({scale})
  const canvas = document.createElement('canvas')
  const context = canvas.getContext('2d')
  canvas.height = viewport.height
  canvas.width = viewport.width
  await page.render({canvasContext: context, viewport}).promise
  pdfContainer.value.appendChild(canvas)
}

const loadPdf = async () => {
  pdfContainer.value.innerHTML = '' // 清空容器
  try {
    const loadingTask = pdfjsLib.getDocument(props.url)
    const pdf = await loadingTask.promise
    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum)
      await renderPage(page)
    }
  } catch (error) {
    console.error('PDF加载失败:', error)
  }
}

onMounted(() => {
  if (props.modelValue) loadPdf()
})
watch(() => props.url, loadPdf)
</script>

<style scoped>
.pdf-container {
  max-height: 75vh;
  overflow-y: auto;
}

canvas {
  display: block;
  margin: 10px auto;
}
</style>
