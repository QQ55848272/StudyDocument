<template>
    <!-- 全屏弹窗遮罩层 -->
    <div v-if="visible" class="fullscreen-preview-modal" @click.self="handleClose">
      <div class="preview-container">
        <!-- 顶部工具栏 -->
        <div class="preview-toolbar">
          <div class="file信息">
            <span class="file-icon">{{ fileIcon }}</span>
            <div class="file-details">
              <span class="file-name">{{ fileName }}</span>
              <span class="file-type">{{ fileType?.toUpperCase() || '未知格式' }}</span>
            </div>
          </div>
          
          <div class="toolbar-actions">
            <a :href="fileUrl" download class="toolbar-btn download-btn">
              <span class="icon">📥</span>
              <span class="tooltip">下载</span>
            </a>
            
            <button class="toolbar-btn close-btn" @click="handleClose">
              <span class="icon">✕</span>
              <span class="tooltip">关闭</span>
            </button>
          </div>
        </div>
        
        <!-- 预览内容区域 -->
        <div class="preview-content">
          <!-- Word/Excel 预览 -->
          <component
            v-if="hasFile && fileType !== 'pdf' && !error"
            :is="previewComponent"
            :src="fileUrl"
            :style="previewStyle"
            @rendered="handleRendered"
            @error="handleError"
          />
  
          <!-- PDF 预览（单独处理） -->
          <vue-office-pdf
            v-if="hasFile && fileType === 'pdf' && !error"
            :src="fileUrl"
            :style="previewStyle"
            @rendered="handlePdfRendered"
            @error="handlePdfError"
          />
  
          <!-- 加载状态 -->
          <div v-if="loading" class="loading-state">
            <div class="loading-spinner"></div>
            <p>正在加载文件...</p>
          </div>
  
          <!-- 错误状态 -->
          <div v-if="error" class="error-state">
            <div class="error-icon">⚠️</div>
            <p>{{ errorMessage }}</p>
            <button @click="retry" class="retry-btn">重试</button>
          </div>
  
          <!-- 不支持的文件类型 -->
          <div v-if="unsupportedType && hasFile" class="unsupported-state">
            <div class="unsupported-icon">📄</div>
            <p>不支持预览此文件类型: {{ fileType }}</p>
            <a :href="fileUrl" download class="download-btn">下载文件</a>
          </div>
  
          <!-- 无文件状态 -->
          <div v-if="!hasFile" class="no-file-state">
            <div class="no-file-icon">📁</div>
            <p>暂无文件可预览</p>
            <p class="hint">请提供文件链接和类型</p>
          </div>
        </div>
        
        <!-- 底部信息栏 -->
        <div class="preview-footer">
          <span class="footer-hint">按 ESC 键或点击空白处关闭</span>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, computed, watch, onMounted, onUnmounted } from "vue";
  import VueOfficeDocx from "@vue-office/docx";
  import VueOfficeExcel from "@vue-office/excel";
  import VueOfficePdf from "@vue-office/pdf";
  
  // 引入相关样式
  import "@vue-office/docx/lib/index.css";
  import "@vue-office/excel/lib/index.css";
  
  // 定义组件属性
  const props = defineProps({
    fileUrl: {
      type: String,
      default: null,
    },
    fileType: {
      type: String,
      default: null,
    },
    fileName: {
      type: String,
      default: "",
    },
    visible: {
      type: Boolean,
      default: false,
    }
  });
  
  // 定义事件
  const emit = defineEmits(["update:visible", "rendered", "error", "close"]);
  
  // 响应式状态
  const loading = ref(false);
  const error = ref(false);
  const errorMessage = ref("");
  const pdfjsLib = ref(null);
  const pdfPreloadError = ref(false); // 新增：PDF预加载错误状态
  
  // 文件类型图标映射
  const fileIcons = {
    pdf: "📕",
    docx: "📘",
    doc: "📘",
    xlsx: "📗",
    xls: "📗",
    default: "📄"
  };
  
  // 计算属性
  const previewStyle = computed(() => ({
    height: '100%',
    overflow: 'auto',
    width: '100%'
  }));
  
  // 检查是否有文件
  const hasFile = computed(() => {
    return props.fileUrl && props.fileType;
  });
  
  // 支持的文件类型映射
  const fileTypeMap = {
    docx: VueOfficeDocx,
    doc: VueOfficeDocx,
    xlsx: VueOfficeExcel,
    xls: VueOfficeExcel,
    pdf: VueOfficePdf,
  };
  
  // 预览组件
  const previewComponent = computed(() => {
    if (!props.fileType) return null;
    const type = props.fileType.toLowerCase();
    return fileTypeMap[type] || null;
  });
  
  // 不支持的格式
  const unsupportedType = computed(() => {
    return hasFile.value && !previewComponent.value;
  });
  
  // 文件名
  const fileName = computed(() => {
    if (props.fileName) return props.fileName;
  
    if (!props.fileUrl) return "未命名文件";
  
    try {
      const url = new URL(props.fileUrl);
      const pathname = url.pathname;
      return pathname.substring(pathname.lastIndexOf("/") + 1) || "未命名文件";
    } catch {
      return (
        props.fileUrl.substring(props.fileUrl.lastIndexOf("/") + 1) ||
        "未命名文件"
      );
    }
  });
  
  const fileIcon = computed(() => {
    if (!props.fileType) return fileIcons.default;
    const type = props.fileType.toLowerCase();
    return fileIcons[type] || fileIcons.default;
  });
  
  const resetState = () => {
    loading.value = false;
    error.value = false;
    pdfPreloadError.value = false; // 重置PDF预加载错误状态
    errorMessage.value = "";
  };
  
  // 动态导入 PDF.js
  onMounted(async () => {
    try {
      // 动态导入 PDF.js
      pdfjsLib.value = await import('pdfjs-dist/build/pdf');
      const pdfjsWorker = await import('pdfjs-dist/build/pdf.worker.entry?url');
      
      // 设置 worker
      pdfjsLib.value.GlobalWorkerOptions.workerSrc = pdfjsWorker.default;
    } catch (err) {
      console.warn('PDF.js 加载失败，PDF预览可能不可用:', err);
    }
  });
  
  // 监听文件URL和类型变化
  watch(
    [() => props.fileUrl, () => props.fileType, () => props.visible],
    ([newUrl, newType, isVisible], [oldUrl, oldType]) => {
      if (isVisible && (newUrl !== oldUrl || newType !== oldType)) {
        resetState();
  
        if (newUrl && newType) {
          loading.value = true;
          
          // 如果是PDF且PDF.js已加载，进行预检查（但不阻塞渲染）
          if (newType.toLowerCase() === 'pdf' && pdfjsLib.value) {
            preloadPdf(newUrl);
          }
        }
      }
    },
    { immediate: true }
  );
  
  // PDF 预加载检查（非阻塞，仅用于检测）
  const preloadPdf = async (url) => {
    if (!pdfjsLib.value) return;
    
    try {
      const loadingTask = pdfjsLib.value.getDocument(url);
      await loadingTask.promise;
      // 预加载成功，不设置错误状态，让vue-office-pdf组件自己处理渲染
    } catch (err) {
      // 预加载失败，记录错误但不阻止渲染尝试
      console.warn('PDF预加载检查失败:', err);
      pdfPreloadError.value = true;
      // 不设置error状态，让vue-office-pdf组件自己尝试渲染
    }
  };
  
  // 方法
  const handleRendered = () => {
    loading.value = false;
    error.value = false;
    emit("rendered");
  };
  
  const handlePdfRendered = () => {
    loading.value = false;
    error.value = false;
    pdfPreloadError.value = false; // PDF渲染成功，清除预加载错误
    emit("rendered");
  };
  
  const handleError = (err) => {
    loading.value = false;
    error.value = true;
    errorMessage.value = err.message || "文件加载失败";
    emit("error", err);
  };
  
  const handlePdfError = (err) => {
    loading.value = false;
    error.value = true;
    
    // 如果预加载已经失败，使用预加载的错误信息
    if (pdfPreloadError.value) {
      errorMessage.value = "PDF文件加载失败：文件可能已损坏或无法访问";
    } else {
      errorMessage.value = `PDF加载失败: ${err.message || '请检查文件链接是否有效'}`;
    }
    
    emit("error", err);
  };
  
  const retry = () => {
    resetState();
    if (hasFile.value) {
      loading.value = true;
      
      // 如果是PDF，重新进行预加载检查
      if (props.fileType.toLowerCase() === 'pdf' && pdfjsLib.value) {
        preloadPdf(props.fileUrl);
      }
    }
  };
  
  const handleClose = () => {
    emit("update:visible", false);
    emit("close");
  };
  
  // 键盘事件处理
  const handleKeydown = (event) => {
    if (event.key === 'Escape' && props.visible) {
      handleClose();
    }
  };
  
  // 生命周期
  onMounted(() => {
    document.addEventListener('keydown', handleKeydown);
  });
  
  onUnmounted(() => {
    document.removeEventListener('keydown', handleKeydown);
  });
  </script>
  
  <style scoped>
  .fullscreen-preview-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.85);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
    animation: fadeIn 0.3s ease;
  }
  
  .preview-container {
    width: 95vw;
    height: 95vh;
    background: white;
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    animation: scaleIn 0.3s ease;
  }
  
  .preview-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 24px;
    background: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
    min-height: 72px;
    flex-shrink: 0;
  }
  
  .file-info {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  
  .file-icon {
    font-size: 24px;
  }
  
  .file-details {
    display: flex;
    flex-direction: column;
  }
  
  .file-name {
    font-weight: 600;
    color: #2c3e50;
    font-size: 16px;
    max-width: 400px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  .file-type {
    font-size: 12px;
    color: #6c757d;
    background: #e9ecef;
    padding: 2px 8px;
    border-radius: 12px;
    margin-top: 2px;
  }
  
  .toolbar-actions {
    display: flex;
    align-items: center;
    gap: 16px;
  }
  
  .toolbar-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border: none;
    background: white;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s;
    position: relative;
  }
  
  .toolbar-btn:hover {
    background: #007bff;
    color: white;
  }
  
  .toolbar-btn:hover .tooltip {
    opacity: 1;
    transform: translateY(-100%);
  }
  
  .tooltip {
    position: absolute;
    top: -8px;
    background: #333;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: all 0.2s;
    z-index: 10;
  }
  
  .close-btn:hover {
    background: #dc3545;
    color: white;
  }
  
  .download-btn {
    text-decoration: none;
    color: inherit;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .preview-content {
    flex: 1;
    position: relative;
    min-height: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
  }
  
  .loading-state,
  .error-state,
  .unsupported-state,
  .no-file-state {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 40px 20px;
    text-align: center;
    width: 100%;
  }
  
  .loading-spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #3498db;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 16px;
  }
  
  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
  
  .error-icon,
  .unsupported-icon,
  .no-file-icon {
    font-size: 48px;
    margin-bottom: 16px;
  }
  
  .no-file-icon {
    opacity: 0.5;
  }
  
  .hint {
    font-size: 14px;
    color: #666;
    margin-top: 8px;
  }
  
  .retry-btn,
  .download-btn {
    padding: 8px 16px;
    background-color: #3498db;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
    text-decoration: none;
  }
  
  .retry-btn:hover,
  .download-btn:hover {
    background-color: #2980b9;
  }
  
  .preview-footer {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 12px 24px;
    background: #f8f9fa;
    border-top: 1px solid #e9ecef;
    color: #6c757d;
    font-size: 14px;
    flex-shrink: 0;
  }
  
  .footer-hint {
    opacity: 0.7;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  @keyframes scaleIn {
    from { 
      opacity: 0;
      transform: scale(0.9);
    }
    to { 
      opacity: 1;
      transform: scale(1);
    }
  }
  
  /* 响应式设计 */
  @media (max-width: 768px) {
    .preview-container {
      width: 100vw;
      height: 100vh;
      border-radius: 0;
    }
    
    .preview-toolbar {
      padding: 12px 16px;
    }
    
    .file-name {
      max-width: 200px;
    }
  }
  
  /* 确保预览组件正确显示 */
  :deep(.vue-office-docx) {
    width: 100% !important;
    height: 100% !important;
    display: block !important;
  }
  
  :deep(.vue-office-excel) {
    width: 100% !important;
    height: 100% !important;
    display: block !important;
  }
  
  :deep(.vue-office-pdf) {
    width: 100% !important;
    height: 100% !important;
    display: block !important;
  }
  </style>