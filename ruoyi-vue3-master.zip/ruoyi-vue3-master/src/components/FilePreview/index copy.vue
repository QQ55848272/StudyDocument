<template>
    <div class="file-preview-container">
      <div class="file-header">
        <span class="file-name">{{ fileName }}</span>
        <span v-if="fileType" class="file-type">{{
          fileType.toUpperCase()
        }}</span>
        <span v-else class="file-type unknown">未知</span>
      </div>
  
      <div class="preview-content">
        <!-- Word/Excel 预览 -->
        <component
          v-if="hasFile && fileType !== 'pdf'"
          :is="previewComponent"
          :src="fileUrl"
          :style="previewStyle"
          @rendered="handleRendered"
          @error="handleError"
        />
  
        <!-- PDF 预览（单独处理） -->
        <vue-office-pdf
          v-if="hasFile && fileType === 'pdf'"
          :src="fileUrl"
          :style="previewStyle"
          @rendered="handlePdfRendered"
          @error="handlePdfError"
        />
  
        <!-- 加载状态 -->
        <div v-if="loading" class="loading-state">
          <div class="loading-spinner"></div>
          <p>正在加载文件...</p>
        </div>
  
        <!-- 错误状态 -->
        <div v-if="error" class="error-state">
          <div class="error-icon">⚠️</div>
          <p>{{ errorMessage }}</p>
          <button @click="retry" class="retry-btn">重试</button>
        </div>
  
        <!-- 不支持的文件类型 -->
        <div v-if="unsupportedType && hasFile" class="unsupported-state">
          <div class="unsupported-icon">📄</div>
          <p>不支持预览此文件类型: {{ fileType }}</p>
          <a :href="fileUrl" download class="download-btn">下载文件</a>
        </div>
  
        <!-- 无文件状态 -->
        <div v-if="!hasFile" class="no-file-state">
          <div class="no-file-icon">📁</div>
          <p>暂无文件可预览</p>
          <p class="hint">请提供文件链接和类型</p>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, computed, watch, onMounted } from "vue";
  import VueOfficeDocx from "@vue-office/docx";
  import VueOfficeExcel from "@vue-office/excel";
  import VueOfficePdf from "@vue-office/pdf";
  
  // 引入相关样式
  import "@vue-office/docx/lib/index.css";
  import "@vue-office/excel/lib/index.css";
  
  // 定义组件属性
  const props = defineProps({
    fileUrl: {
      type: String,
      default: null,
    },
    fileType: {
      type: String,
      default: null,
    },
    fileName: {
      type: String,
      default: "",
    },
    height: {
      type: String,
      default: "100vh",
    },
  });
  
  // 定义事件
  const emit = defineEmits(["rendered", "error"]);
  
  // 响应式状态
  const loading = ref(false);
  const error = ref(false);
  const errorMessage = ref("");
  const pdfjsLib = ref(null);
  
  // 计算属性
  const previewStyle = computed(() => ({
    height: props.height,
    overflow: "auto",
    width: "100%"
  }));
  
  // 检查是否有文件
  const hasFile = computed(() => {
    return props.fileUrl && props.fileType;
  });
  
  // 支持的文件类型映射
  const fileTypeMap = {
    docx: VueOfficeDocx,
    doc: VueOfficeDocx,
    xlsx: VueOfficeExcel,
    xls: VueOfficeExcel,
    pdf: VueOfficePdf,
  };
  
  // 预览组件
  const previewComponent = computed(() => {
    if (!props.fileType) return null;
    const type = props.fileType.toLowerCase();
    return fileTypeMap[type] || null;
  });
  
  // 不支持的格式
  const unsupportedType = computed(() => {
    return hasFile.value && !previewComponent.value;
  });
  
  // 文件名
  const fileName = computed(() => {
    if (props.fileName) return props.fileName;
  
    if (!props.fileUrl) return "未命名文件";
  
    try {
      const url = new URL(props.fileUrl);
      const pathname = url.pathname;
      return pathname.substring(pathname.lastIndexOf("/") + 1) || "未命名文件";
    } catch {
      return (
        props.fileUrl.substring(props.fileUrl.lastIndexOf("/") + 1) ||
        "未命名文件"
      );
    }
  });
  
  const resetState = () => {
    loading.value = false;
    error.value = false;
    errorMessage.value = "";
  };
  
  // 动态导入 PDF.js
  onMounted(async () => {
    try {
      // 动态导入 PDF.js
      pdfjsLib.value = await import('pdfjs-dist/build/pdf');
      const pdfjsWorker = await import('pdfjs-dist/build/pdf.worker.entry?url');
      
      // 设置 worker
      pdfjsLib.value.GlobalWorkerOptions.workerSrc = pdfjsWorker.default;
    } catch (err) {
      console.warn('PDF.js 加载失败，PDF预览可能不可用:', err);
    }
  });
  
  // 监听文件URL和类型变化
  watch(
    [() => props.fileUrl, () => props.fileType],
    ([newUrl, newType], [oldUrl, oldType]) => {
      if (newUrl !== oldUrl || newType !== oldType) {
        resetState();
  
        if (newUrl && newType) {
          loading.value = true;
          
          // 如果是PDF且PDF.js已加载，进行预检查
          if (newType.toLowerCase() === 'pdf' && pdfjsLib.value) {
            preloadPdf(newUrl);
          }
        }
      }
    },
    { immediate: true }
  );
  
  // PDF 预加载检查
  const preloadPdf = async (url) => {
    if (!pdfjsLib.value) return;
    
    try {
      const loadingTask = pdfjsLib.value.getDocument(url);
      await loadingTask.promise;
    } catch (err) {
      handlePdfError(err);
    }
  };
  
  // 方法
  const handleRendered = () => {
    loading.value = false;
    emit("rendered");
  };
  
  const handlePdfRendered = () => {
    loading.value = false;
    emit("rendered");
  };
  
  const handleError = (err) => {
    loading.value = false;
    error.value = true;
    errorMessage.value = err.message || "文件加载失败";
    emit("error", err);
  };
  
  const handlePdfError = (err) => {
    loading.value = false;
    error.value = true;
    errorMessage.value = `PDF加载失败: ${err.message || '请检查文件链接是否有效'}`;
    emit("error", err);
  };
  
  const retry = () => {
    resetState();
    if (hasFile.value) {
      loading.value = true;
    }
  };
  </script>
  
  <style scoped>
  .file-preview-container {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    background-color: white;
  }
  
  .file-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background-color: #f5f5f5;
    border-bottom: 1px solid #e0e0e0;
  }
  
  .file-name {
    font-weight: 500;
    color: #333;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    flex: 1;
    margin-right: 12px;
  }
  
  .file-type {
    font-size: 12px;
    color: #666;
    background-color: #e0e0e0;
    padding: 2px 8px;
    border-radius: 12px;
    white-space: nowrap;
  }
  
  .file-type.unknown {
    background-color: #ffebee;
    color: #c62828;
  }
  
  .preview-content {
    position: relative;
    min-height: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .loading-state,
  .error-state,
  .unsupported-state,
  .no-file-state {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 40px 20px;
    text-align: center;
    width: 100%;
  }
  
  .loading-spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #3498db;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 16px;
  }
  
  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
  
  .error-icon,
  .unsupported-icon,
  .no-file-icon {
    font-size: 48px;
    margin-bottom: 16px;
  }
  
  .no-file-icon {
    opacity: 0.5;
  }
  
  .hint {
    font-size: 14px;
    color: #666;
    margin-top: 8px;
  }
  
  .retry-btn,
  .download-btn {
    margin-top: 16px;
    padding: 8px 16px;
    background-color: #3498db;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
    text-decoration: none;
    display: inline-block;
  }
  
  .retry-btn:hover,
  .download-btn:hover {
    background-color: #2980b9;
  }
  </style>