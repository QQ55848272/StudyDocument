<template>
  <div class="chat-container">
    <div class="chat-box">
      <div class="chat-content">
        <div
            v-for="(message, index) in messages"
            :key="index"
            :class="['message', message.sender === 'user' ? 'user-message' : 'assistant-message']"
        >
          <el-avatar
              :src="message.sender === 'user' ? userAvatar : assistantAvatar"
              class="avatar"
          />
          <div class="content">{{ message.text }}</div>
        </div>
      </div>
    </div>

    <div class="input-container">
      <el-input
          v-model="userInput"
          placeholder="请输入消息..."
          @keyup.enter="sendMessage"
          class="input-box"
      />
      <el-button type="primary" round @click="sendMessage">
        发送
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref,nextTick } from "vue";
import axios from "axios";

const userInput = ref("");
const messages = ref<{ text: string; sender: string }[]>([]);
const userAvatar = "/avatar/profile.jpg";
const assistantAvatar = "/avatar/gov.png";

const sendMessage = async () => {
  if (!userInput.value.trim()) return;

  messages.value.push({ text: userInput.value, sender: "user" });

  await nextTick(); // 让 Vue 先渲染消息

  try {
    const response = await axios.post("http://10.191.39.215:8002/chat/generate", {
      system: "",
      contextMessage: [{ user: userInput.value, assistant: "" }]
    });

    messages.value.push({ text: response.data.result.output.text, sender: "assistant" });
  } catch (error) {
    messages.value.push({ text: "请求失败，请稍后重试", sender: "assistant" });
  }

  userInput.value = "";
};
</script>

<style scoped>
/* 🌟 整体容器美化 */
.chat-container {
  width: 90%;
  min-height: 80vh;
  max-width: 2480px;
  background: white;
  padding: 14px;
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  align-items: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

/* 🌟 聊天框 */
.chat-box {
  flex: 1; /* 让聊天框占据可用空间 */
  width: 100%;
  min-height: 300px; /* 设置最小高度，避免窗口太小 */
  max-height: 100vh; /* 防止高度过大 */
  overflow-y: auto;
  background: #f9fafb;
  padding: 10px;
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

/* 🌟 消息列表 */
.chat-content {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

/* 🌟 消息气泡 */
.message {
  display: flex;
  align-items: center;
  gap: 10px;
  max-width: 80%;
  word-wrap: break-word;
}

/* 🌟 用户消息 */
.user-message {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.user-message .content {
  background: #007bff;
  color: white;
}

/* 🌟 AI 消息 */
.assistant-message {
  align-self: flex-start;
}

.assistant-message .content {
  background: #e5e7eb;
  color: black;
}

/* 🌟 头像 */
.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
}

/* 🌟 气泡内容 */
.content {
  padding: 12px 15px;
  border-radius: 16px;
  max-width: 70%;
  line-height: 1.5;
  box-shadow: 2px 4px 10px rgba(0, 0, 0, 0.1);
}

/* 🌟 输入框区域 */
.input-container {
  display: flex;
  gap: 10px;
  margin-top: 15px;
  width: 100%;
}

.input-box {
  flex: 1;
}

/* 🌟 发送按钮 */
.el-button {
  font-size: 16px;
  padding: 10px 24px;
}
</style>
