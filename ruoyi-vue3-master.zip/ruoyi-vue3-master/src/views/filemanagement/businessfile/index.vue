<template>
  <div class="app-container">
    <el-form :inline="true" :model="queryParams" class="mb-3">
      <el-form-item label="关键字">
        <el-input
          v-model="queryParams.keyword"
          placeholder="请输入文件名或分类"
          clearable
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleQuery">查询</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-table :data="pdfList" stripe border style="width: 100%">
      <el-table-column label="文件名" prop="filename" />
      <el-table-column label="分类" prop="category" />
      <el-table-column label="上传时间" prop="uploadTime" />
      <el-table-column label="操作" align="center" width="120">
        <template #default="scope">
          <el-button type="primary" link @click="handleView(scope.row)"
            >查看</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <!-- PDF 预览弹窗组件 -->
    <!-- <PdfViewer ref="pdfViewerRef" /> -->
    <FileViewer
     v-model:visible="previewVisible"
        :file-url="viewer.url"
        :file-type="viewer.type"
        :file-name="viewer.name"
        @close="handleClose"
      />
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { ElMessage } from "element-plus";
import FileViewer from "../../../components/FilePreview/index.vue";
import { queryPdfList } from "@/api/filemanagement/index.js";
const pdfList = ref([]);
const queryParams = ref({
  keyword: "",
});

const viewer= ref({
  url:null,
  type:null,
  name:null
});

const previewVisible = ref(false);

const getList = async () => {
  try {
    const data = await queryPdfList(queryParams.value);

    if (data.code === 200) {
      pdfList.value = data.data;
    } else {
      ElMessage.error("查询失败");
    }
  } catch (error) {
    ElMessage.error("网络异常");
  }
};

const handleQuery = () => {
  getList();
};

const resetQuery = () => {
  queryParams.value.keyword = "";
  getList();
};

const handleView = (row) => {
  const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL || "http://10.190.196.98:8080";
  const filename = encodeURIComponent(row.filepath);
  const url = `${API_BASE_URL}/files/view/${filename}`;
  viewer.value.name = row.filename;
  viewer.value.url = url;
  viewer.value.type = row.filepath.split('.').pop();
  previewVisible.value = true;

};

const handleClose = () => {
  console.log('预览窗口已关闭')
}

onMounted(() => {
  getList();
});
</script>

<style scoped>
.mb-3 {
  margin-bottom: 20px;
}
</style>
