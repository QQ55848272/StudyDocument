<template>
  <div class="app-container">
    <el-card>
      <h2>上传 PDF 文件</h2>
      <el-form label-width="100px" class="upload-form">
        <el-form-item label="文件名称">
          <el-input v-model="form.filename" placeholder="请输入文件名称" />
        </el-form-item>
        <el-form-item label="分类">
          <el-input v-model="form.category" placeholder="请输入分类" />
        </el-form-item>
        <el-form-item label="选择文件">
          <el-upload
              class="upload"
              ref="uploadRef"
              :auto-upload="false"
              :before-upload="beforeUpload"
              :on-change="handleFileChange"
              :show-file-list="true"
              accept=".pdf"
          >
            <el-button type="primary">选择 PDF 文件</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item>
          <el-button type="success" @click="submitUpload">上传文件</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getToken } from '@/utils/auth'
import axios from '@/utils/request'

const uploadRef = ref()
const selectedFile = ref(null)

const form = reactive({
  filename: '',
  category: ''
})

const handleFileChange = (uploadFile) => {
  selectedFile.value = uploadFile.raw
}

const beforeUpload = (file) => {
  if (!file.name.endsWith('.pdf')) {
    ElMessage.error('只能上传 PDF 文件！')
    return false
  }
  return true
}

const submitUpload = async () => {
  if (!form.filename || !form.category) {
    ElMessage.error('请填写文件名称和分类')
    return
  }
  if (!selectedFile.value) {
    ElMessage.error('请先选择 PDF 文件')
    return
  }

  const formData = new FormData()
  formData.append('file', selectedFile.value)
  formData.append('filename', form.filename)
  formData.append('category', form.category)

  try {
    await axios.post(`/files/upload`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        Authorization: 'Bearer ' + getToken()
      }
    })
    ElMessage.success('上传成功')
    form.filename = ''
    form.category = ''
    uploadRef.value.clearFiles()
    selectedFile.value = null
  } catch (e) {
    ElMessage.error('上传失败')
  }
}
</script>

<style scoped>
.pdf-upload {
  padding: 20px;
  max-width: 600px;
  margin: auto;
}

.upload-form {
  margin-top: 20px;
}
</style>
