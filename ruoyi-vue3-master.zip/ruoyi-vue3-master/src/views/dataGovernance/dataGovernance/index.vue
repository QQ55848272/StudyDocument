<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="厂别" prop="site">
        <el-input
          v-model="queryParams.site"
          placeholder="请输入厂别"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="用户名" prop="dataSchema">
        <el-input
          v-model="queryParams.dataSchema"
          placeholder="请输入用户名"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="厂内机种" prop="model">
        <el-input
          v-model="queryParams.model"
          placeholder="请输入厂内机种"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="数据源" prop="dataSource">
        <el-input
          v-model="queryParams.dataSource"
          placeholder="请输入数据源"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="客户机种" prop="customerModel">
        <el-input
          v-model="queryParams.customerModel"
          placeholder="请输入客户机种"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="表名" prop="tableName">
        <el-input
          v-model="queryParams.tableName"
          placeholder="请输入表名"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['dataGovernance:dataGovernance:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['dataGovernance:dataGovernance:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['dataGovernance:dataGovernance:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['dataGovernance:dataGovernance:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="dataGovernanceList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="主键ID" align="center" prop="id" />
      <el-table-column label="厂别" align="center" prop="site" />
      <el-table-column label="用户名" align="center" prop="dataSchema" />
      <el-table-column label="厂内机种" align="center" prop="model" />
      <el-table-column label="数据源" align="center" prop="dataSource" />
      <el-table-column label="客户机种" align="center" prop="customerModel" />
      <el-table-column label="表名" align="center" prop="tableName" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['dataGovernance:dataGovernance:edit']">修改</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['dataGovernance:dataGovernance:remove']">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改schema下包含信息对话框 -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="dataGovernanceRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="厂别" prop="site">
          <el-input v-model="form.site" placeholder="请输入厂别" />
        </el-form-item>
        <el-form-item label="用户名" prop="dataSchema">
          <el-input v-model="form.dataSchema" placeholder="请输入用户名" />
        </el-form-item>
        <el-form-item label="厂内机种" prop="model">
          <el-input v-model="form.model" placeholder="请输入厂内机种" />
        </el-form-item>
        <el-form-item label="数据源" prop="dataSource">
          <el-input v-model="form.dataSource" placeholder="请输入数据源" />
        </el-form-item>
        <el-form-item label="客户机种" prop="customerModel">
          <el-input v-model="form.customerModel" placeholder="请输入客户机种" />
        </el-form-item>
        <el-form-item label="表名" prop="tableName">
          <el-input v-model="form.tableName" placeholder="请输入表名" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="DataGovernance">
import { listDataGovernance, getDataGovernance, delDataGovernance, addDataGovernance, updateDataGovernance } from "@/api/dataGovernance/dataGovernance";

const { proxy } = getCurrentInstance();

const dataGovernanceList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    site: null,
    dataSchema: null,
    model: null,
    dataSource: null,
    customerModel: null,
    tableName: null,
  },
  rules: {
    site: [
      { required: true, message: "厂别不能为空", trigger: "blur" }
    ],
    dataSchema: [
      { required: true, message: "用户名不能为空", trigger: "blur" }
    ],
    model: [
      { required: true, message: "厂内机种不能为空", trigger: "blur" }
    ],
    dataSource: [
      { required: true, message: "数据源不能为空", trigger: "blur" }
    ],
    customerModel: [
      { required: true, message: "客户机种不能为空", trigger: "blur" }
    ],
    tableName: [
      { required: true, message: "表名不能为空", trigger: "blur" }
    ],
  }
});

const { queryParams, form, rules } = toRefs(data);

/** 查询schema下包含信息列表 */
function getList() {
  loading.value = true;
  listDataGovernance(queryParams.value).then(response => {
    dataGovernanceList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// 取消按钮
function cancel() {
  open.value = false;
  reset();
}

// 表单重置
function reset() {
  form.value = {
    id: null,
    site: null,
    dataSchema: null,
    model: null,
    dataSource: null,
    customerModel: null,
    tableName: null,
    createBy: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
    remark: null
  };
  proxy.resetForm("dataGovernanceRef");
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "添加schema下包含信息";
}

/** 修改按钮操作 */
function handleUpdate(row) {
  reset();
  const _id = row.id || ids.value
  getDataGovernance(_id).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "修改schema下包含信息";
  });
}

/** 提交按钮 */
function submitForm() {
  proxy.$refs["dataGovernanceRef"].validate(valid => {
    if (valid) {
      if (form.value.id != null) {
        updateDataGovernance(form.value).then(response => {
          proxy.$modal.msgSuccess("修改成功");
          open.value = false;
          getList();
        });
      } else {
        addDataGovernance(form.value).then(response => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal.confirm('是否确认删除schema下包含信息编号为"' + _ids + '"的数据项？').then(function() {
    return delDataGovernance(_ids);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("删除成功");
  }).catch(() => {});
}

/** 导出按钮操作 */
function handleExport() {
  proxy.download('dataGovernance/dataGovernance/export', {
    ...queryParams.value
  }, `dataGovernance_${new Date().getTime()}.xlsx`)
}

getList();
</script>
