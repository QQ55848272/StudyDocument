<template>
  <div class="app-container">
    <el-form :inline="true" :model="queryParams">
      <el-form-item label="库名">
        <el-select v-model="queryParams.table_schema" placeholder="请选择库名" clearable>
          <el-option v-for="schema in schemaList" :key="schema" :label="schema" :value="schema" />
        </el-select>
      </el-form-item>
      <el-form-item label="表名">
        <el-input v-model="queryParams.table_name" placeholder="请输入表名" clearable />
      </el-form-item>
      <el-form-item label="表注释">
        <el-input v-model="queryParams.table_comment" placeholder="请输入表注释" clearable />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleQuery">查询</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-table :data="tableData" border style="width: 100%; margin-top: 20px">
      <el-table-column label="库名" prop="tableSchema" />
      <el-table-column label="表名" prop="tableName" />
      <el-table-column label="类型" prop="tableType" />
      <el-table-column label="表注释" prop="tableComment" />
      <el-table-column label="操作" width="220">
        <template #default="scope">
          <el-button type="primary" size="small" @click="showColumn(scope.row)">字段元数据</el-button>
          <el-button type="success" size="small" @click="showTable(scope.row)">表元数据</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 字段元数据弹窗 -->
    <el-dialog title="字段元数据" v-model="columnDialogVisible" width="800px">
      <el-table :data="columnData" border>
        <el-table-column prop="columnName" label="字段名" />
        <el-table-column prop="columnType" label="字段类型" />
        <el-table-column prop="isNullable" label="是否可为空" />
        <el-table-column prop="columnKey" label="主键" />
        <el-table-column prop="columnComment" label="字段注释" />
      </el-table>
    </el-dialog>

    <!-- 表元数据弹窗 -->
    <el-dialog title="表元数据" v-model="tableDialogVisible" width="600px">
      <el-descriptions title="" column="1" border>
        <el-descriptions-item label="表名">{{ tableDetail.tableName }}</el-descriptions-item>
        <el-descriptions-item label="库名">{{ tableDetail.tableSchema }}</el-descriptions-item>
        <el-descriptions-item label="类型">{{ tableDetail.tableType }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{ tableDetail.createTime }}</el-descriptions-item>
        <el-descriptions-item label="更新时间">{{ tableDetail.updateTime }}</el-descriptions-item>
        <el-descriptions-item label="行数">{{ tableDetail.tableRows }}</el-descriptions-item>
        <el-descriptions-item label="数据大小(GB)">{{ tableDetail.dataLength }}</el-descriptions-item>
        <el-descriptions-item label="表注释">{{ tableDetail.tableComment }}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getSchemas, getTableList, getColumnList, getTableMetadata } from '@/api/governance/metadata'

const queryParams = ref({
  table_schema: '',
  table_name: '',
  table_comment: ''
})

const schemaList = ref([])
const tableData = ref([])
const columnData = ref([])
const tableDetail = ref({})

const columnDialogVisible = ref(false)
const tableDialogVisible = ref(false)

const getSchemaList = async () => {
  const res = await getSchemas()
  if (res.code === 200) schemaList.value = res.data
}

const getTableData = async () => {
  const res = await getTableList(queryParams.value.table_schema,queryParams.value.table_name,queryParams.value.table_comment)
  if (res.code === 200) {
    tableData.value = res.data
  } else {
    ElMessage.error('获取表列表失败')
  }
}

const handleQuery = async () => {
  await getTableData()
}

const resetQuery = () => {
  queryParams.value = { table_schema: '', table_name: '', table_comment: '' }

}

const showColumn = async (row) => {
  const res = await getColumnList(row.tableSchema, row.tableName)
  if (res.code === 200) {
    columnData.value = res.data
    columnDialogVisible.value = true
  } else {
    ElMessage.error('获取字段信息失败')
  }
}

const showTable = async (row) => {
  const res = await getTableMetadata(row.tableSchema, row.tableName)
  if (res.code === 200 && res.data.length > 0) {
    tableDetail.value = res.data[0]
    tableDialogVisible.value = true
  } else {
    ElMessage.error('获取表信息失败')
  }
}

onMounted(() => {
  getSchemaList()
  getTableData()
})
</script>
