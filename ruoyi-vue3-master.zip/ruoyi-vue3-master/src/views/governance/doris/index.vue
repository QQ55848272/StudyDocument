<template>
  <div class="content">
    <el-row :gutter="20">
      <el-col :span="8">
        <el-input v-model="query.tableSchema" placeholder="请输入数据库名" />
      </el-col>
      <el-col :span="8">
        <el-input v-model="query.tableName" placeholder="请输入表名" />
      </el-col>
      <el-col :span="8">
        <el-input v-model="query.tableComment" placeholder="请输入表描述" />
      </el-col>
      <el-col :span="24">
        <el-button type="primary" @click="handleSearch">查询</el-button>
      </el-col>
    </el-row>

    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="tableSchema" label="数据库名" width="100"/>
      <el-table-column prop="tableName" label="表名" width="180"/>
      <el-table-column prop="tableType" label="表类型" width="80"/>
      <el-table-column prop="createTime" label="创建时间" width="180"/>
      <el-table-column prop="updateTime" label="更新时间" width="180"/>
      <el-table-column prop="tableRows" label="行数" width="80"/>
      <el-table-column prop="dataLength" label="数据大小(GB)" width="80"/>
      <el-table-column prop="tableComment" label="表描述" width="180"/>
    </el-table>
  </div>
</template>

<script>
import { getDorisTableList } from '@/api/governance/metadata';  // 引入封装好的 API 请求方法

export default {
  data() {
    return {
      query: {
        tableSchema: '',
        tableName: '',
        tableComment: ''
      },
      tableData: []  // 存储查询结果
    };
  },
  methods: {
    // 查询按钮的处理方法
    async handleSearch() {
      const params = {
        tableSchema: this.query.tableSchema,
        tableName: this.query.tableName,
        tableComment: this.query.tableComment
      };
      try {
        const response = await getDorisTableList(params);  // 调用封装的 API 请求
        if (response.code === 200) {
          this.tableData = response.data;  // 获取数据并更新
        } else {
          this.$message.error('查询失败');
        }
      } catch (error) {
        this.$message.error('查询请求失败');
      }
    }
  }
};
</script>

<style scoped>
/* 添加样式 */
</style>
