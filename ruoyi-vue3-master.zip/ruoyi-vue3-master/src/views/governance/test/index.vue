<template>
  <div>
    <!-- 用户列表 -->
    <el-table :data="userList" style="width: 100%" border>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="name" label="姓名">
        <template #default="{ row }">
          <el-button type="text" @click="showDialog(row)">
            {{ row.name }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column prop="email" label="邮箱" />
    </el-table>

    <!-- Dialog 对话框 -->
    <el-dialog
        v-model="dialogVisible"
        title="用户订单列表"
        width="600px"
    >
      <el-table :data="orderList" style="width: 100%" border>
        <el-table-column prop="orderId" label="订单ID" />
        <el-table-column prop="product" label="产品" />
        <el-table-column prop="price" label="价格" />
      </el-table>
      <template #footer>
        <el-button @click="dialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref } from 'vue'

// 模拟用户列表数据
const userList = ref([
  { id: 1, name: '张三', email: 'zhangsan@example.com' },
  { id: 2, name: '李四', email: 'lisi@example.com' },
  { id: 3, name: '王五', email: 'wangwu@example.com' }
])

// 控制 Dialog 显示
const dialogVisible = ref(false)

// 当前选中用户的订单列表
const orderList = ref([])

// 模拟获取订单数据的方法
function getOrdersByUserId(userId) {
  return [
    { orderId: `${userId}-A1`, product: '手机', price: 1999 },
    { orderId: `${userId}-B2`, product: '电脑', price: 4999 }
  ]
}

// 点击“姓名”时显示 Dialog 并加载数据
function showDialog(user) {
  orderList.value = getOrdersByUserId(user.id)
  dialogVisible.value = true
}
</script>
