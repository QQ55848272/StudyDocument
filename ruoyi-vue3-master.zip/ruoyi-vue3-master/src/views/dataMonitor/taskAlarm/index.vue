<template>
  <div class="app-container">
    <!-- 搜索区域 -->
    <div class="lx-search-bar" v-show="showSearch">
      <el-form
        ref="queryFormRef"
        :model="queryParams"
        :inline="true"
        label-position="top"
      >
        <el-form-item label="执行ID">
          <el-input
            v-model.trim="queryParams.execId"
            placeholder="请输入执行ID"
            clearable
            @keyup.enter="handleSearch"
          />
        </el-form-item>
        <el-form-item label="任务流名称">
          <el-input
            v-model.trim="queryParams.workflowName"
            placeholder="请输入任务流名称"
            clearable
            @keyup.enter="handleSearch"
          />
        </el-form-item>

        <el-form-item label="任务名称">
          <el-input
            v-model.trim="queryParams.jobName"
            placeholder="请输入任务名称"
            clearable
            @keyup.enter="handleSearch"
          />
        </el-form-item>

        <el-form-item label="解决状态">
          <el-select
            v-model="queryParams.solveFlag"
            placeholder="请选择"
            clearable
            @change="handleSearch"
          >
            <el-option
              v-for="item in solveOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="处理状态">
          <el-select
            v-model="queryParams.handleFlag"
            placeholder="请选择"
            clearable
            @change="handleSearch"
          >
            <el-option
              v-for="item in handleOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="错误类型">
          <el-select
            v-model="queryParams.errorType"
            placeholder="请选择"
            clearable
            @change="handleSearch"
          >
            <el-option
              v-for="item in errorTypeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="创建人">
          <el-select
            v-model="queryParams.realName"
            placeholder="请选择责任人"
            filterable
            clearable
            @change="handleSearch"
          >
            <el-option
              v-for="item in creatorOptions"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="日期范围">
          <el-date-picker
            v-model="timeRange"
            type="datetimerange"
            align="right"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :default-time="[
              new Date(new Date().setHours(0, 0, 0, 0)),
              new Date(new Date().setHours(23, 59, 59, 999)),
            ]"
            format="YYYY-MM-DD HH:mm:ss"
            value-format="YYYY-MM-DD HH:mm:ss"
            @change="handleTimeRangeChange"
          />
        </el-form-item>

        <el-form-item class="form-actions">
          <el-button
            type="primary"
            :icon="Search"
            @click="handleSearch"
            :loading="loading"
          >
            搜索
          </el-button>
          <el-button :icon="Refresh" @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="lx-tool">
      <span class="total"> 告警 {{ pagination.total }} 条</span>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="handleSearch"
      ></right-toolbar>
    </div>
    <!-- 表格区域 -->
    <div class="lx-table-container">
      <el-table
        :data="tableData"
        v-loading="loading"
        style="width: 100%"
        :header-cell-style="tableHeaderStyle"
        border
        stripe
      >
        <el-table-column
          prop="execId"
          label="执行ID"
          width="100"
          align="center"
        />
        <el-table-column
          prop="workflowName"
          label="任务流名称"
          min-width="200"
          show-overflow-tooltip
        />
        <el-table-column
          prop="jobName"
          label="任务名称"
          min-width="250"
          show-overflow-tooltip
        />
        <el-table-column
          prop="createBy"
          label="创建人"
          width="120"
          align="center"
        />
        <el-table-column
          prop="errorType"
          label="错误类型"
          width="120"
          align="center"
        />
        <el-table-column
          prop="startTimestamp"
          label="开始时间"
          width="180"
          align="center"
        />

        <el-table-column
          prop="handleFlag"
          label="处理状态"
          width="120"
          align="center"
        >
          <template #default="{ row }">
            <el-button
              v-if="row.handleFlag === '未处理'"
              type="danger"
              size="small"
              @click="handleSolve(row)"
            >
              {{ row.handleFlag }}
            </el-button>
            <el-tag v-else size="small">
              {{ row.handleFlag }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column
          prop="solveFlag"
          label="解决状态"
          width="120"
          align="center"
        >
          <template #default="{ row }">
            <el-tag
              :type="row.solveFlag === '已解决' ? 'success' : 'danger'"
              size="small"
              v-if="row.solveFlag"
            >
              {{ row.solveFlag }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column label="操作" width="200" align="center" fixed="right">
          <template #default="{ row }">
            <el-button
              type="primary"
              link
              size="small"
              @click="handleShowLog(row)"
            >
              执行日志
            </el-button>
            <el-button
              type="primary"
              link
              size="small"
              @click="handleViewDetail(row)"
            >
              处理详情
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="lx-pagination-container">
      <el-pagination
        v-model:current-page="pagination.currentPage"
        v-model:page-size="pagination.pageSize"
        :page-sizes="[10, 20, 50, 100]"
        :total="pagination.total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>

    <!-- 弹窗组件 -->
    <AlarmDetailDialog ref="alarmDetailDialogRef" @refresh="handleSearch" />
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from "vue";
import dayjs from "dayjs";
import { ElMessage } from "element-plus";
import { Search, Refresh } from "@element-plus/icons-vue";
import AlarmDetailDialog from "./addItem.vue";
import {
  listTaskAlarm,
  queryEmployer,
} from "../../../api/dataMonitor/taskAlarm.js";

// 响应式数据
const timeRange = ref([]);
const queryFormRef = ref();
const alarmDetailDialogRef = ref();
const loading = ref(false);
const tableData = ref([]);
const showSearch = ref(true);

//
// 查询参数
const queryParams = reactive({
  workflowName: "",
  jobName: "",
  startTime: "",
  endTime: "",
  realName: "",
  handleFlag: "",
  solveFlag: "",
  errorType: "",
  execId: "",
});

// 分页配置
const pagination = reactive({
  total: 0,
  currentPage: 1,
  pageSize: 10,
});

// 选项数据
const solveOptions = [
  { value: "", label: "全部" },
  { value: "已解决", label: "已解决" },
  { value: "未解决已有对策", label: "未解决已有对策" },
  { value: "未解决未有对策", label: "未解决未有对策" },
];

const handleOptions = [
  { value: "", label: "全部" },
  { value: "已处理", label: "已处理" },
  { value: "未处理", label: "未处理" },
];

const errorTypeOptions = [
  { value: "", label: "全部" },
  { value: "平台", label: "平台" },
  { value: "doris", label: "doris" },
  { value: "源系统", label: "源系统" },
  { value: "网络", label: "网络" },
  { value: "开发Bug", label: "开发Bug" },
  { value: "其它", label: "其它" },
];

// 计算属性
const creatorOptions = ref([]);

// 查询责任人
const handleEmployer = async () => {
  try {
    const response = await queryEmployer();
    console.log("response:", response);
    creatorOptions.value = response.data.map((item) =>item.createBy);
  } catch (error) {
    console.error("获取责任人列表失败:", error);
    ElMessage.error("获取数据失败，请重试");
    return [];
  }
};

// 表格头部样式
const tableHeaderStyle = {
  fontSize: "14px",
  textAlign: "center",
  fontWeight: "bold",
  backgroundColor: "#F7F9FC",
  color: "#1F2E4D",
};

// 方法
const handleSearch = async () => {
  try {
    loading.value = true;
    const filteredParams = {};
    Object.keys(queryParams).forEach((key) => {
      if (queryParams[key] !== "") {
        filteredParams[key] = queryParams[key];
      }
    });
    const response = await listTaskAlarm({
      ...filteredParams,
      pageNum: pagination.currentPage,
      pageSize: pagination.pageSize,
    });
    tableData.value = response.data.list;
    pagination.total = response.data.total;
  } catch (error) {
    ElMessage.error("获取数据失败，请重试");
    tableData.value = [];
    pagination.total = 0;
  } finally {
    loading.value = false;
  }
};

const handleReset = () => {
  // 重置表单
  if (queryFormRef.value) {
    queryFormRef.value.resetFields();
  }
  timeRange.value = [];
  Object.keys(queryParams).forEach((key) => {
    queryParams[key] = "";
  });
  handleSearch();
};

const handleTimeRangeChange = (value) => {
  if (value && value.length === 2) {
    queryParams.startTime = value[0];
    queryParams.endTime = value[1];
  } else {
    queryParams.startTime = "";
    queryParams.endTime = "";
  }
};

const handleSolve = (row) => {
  alarmDetailDialogRef.value?.show(row, "deal");
};

const handleShowLog = (row) => {
  alarmDetailDialogRef.value?.show(row, "log");
};

const handleViewDetail = (row) => {
  alarmDetailDialogRef.value?.show(row, "detail");
};

const handleSizeChange = (newSize) => {
  pagination.pageSize = newSize;
  pagination.currentPage = 1;
  handleSearch();
};

const handleCurrentChange = (newPage) => {
  pagination.currentPage = newPage;
  handleSearch();
};

// 生命周期
onMounted(() => {
  const now = new Date();
  timeRange.value[0] = `${now.getFullYear()}-${String(
    now.getMonth() + 1
  ).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")} 00:00:00`;
  timeRange.value[1] = dayjs().format("YYYY-MM-DD HH:mm:ss");
  queryParams.startTime = timeRange.value[0];
  queryParams.endTime = timeRange.value[1];
  handleEmployer();
  handleSearch();
});
</script>

<style lang="scss" scoped></style>
