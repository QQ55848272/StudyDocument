<template>
  <de-modal
    :title="title"
    v-model:visible="visible"
    @ok="handleSubmit"
    @cancel="handleCancel"
    :width="dialogWidth"
    :confirm-loading="loading"
    :showFooter="detailType === 'deal'"
    v-model:isFullScreen="isFullScreen"
  >
    <div class="dialog-box">
      <!-- 处理表单 -->
      <el-form
        v-if="detailType === 'deal'"
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="100px"
        class="lx-form"
      >
        <el-form-item label="执行ID">
          <el-input v-model="formData.execId" disabled />
        </el-form-item>
        <el-form-item label="任务流名称">
          <el-input v-model="formData.workflowName" disabled />
        </el-form-item>
        <el-form-item label="任务名称">
          <el-input v-model="formData.jobName" disabled />
        </el-form-item>
        <el-form-item label="修改人名称">
          <el-input v-model="formData.createBy" clearable />
        </el-form-item>
        <el-form-item label="报警原因" prop="alarmReasion">
          <el-input
            v-model="formData.alarmReasion"
            type="textarea"
            :rows="3"
            placeholder="请输入报警原因"
            maxlength="500"
            show-word-limit
          />
        </el-form-item>
        <el-form-item label="错误类型" prop="errorType">
          <el-radio-group v-model="formData.errorType">
            <el-radio
              v-for="item in errorTypeOptions"
              :key="item.value"
              :label="item.value"
            >
              {{ item.label }}
            </el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="解决状态" prop="solveFlag">
          <el-radio-group v-model="formData.solveFlag">
            <el-radio
              v-for="item in solveOptions"
              :key="item.value"
              :label="item.value"
            >
              {{ item.label }}
            </el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>

      <!-- 执行日志 -->
      <div v-else-if="detailType === 'log'" class="log-container">
        <div class="log-header">
          <el-button
            type="primary"
            link
            :icon="Refresh"
            @click="handleQueryLog(null)"
            :loading="logLoading"
          >
            刷新
          </el-button>
        </div>
        <div class="log-content">
          <el-scrollbar
            v-loading="logLoading"
            :style="{ height: scrollHeight }"
          >
            <pre v-if="logContent" class="log-text">{{ logContent }}</pre>
            <div v-else class="empty-log">
              <el-empty description="暂无日志数据" />
            </div>
          </el-scrollbar>
        </div>
      </div>

      <!-- 任务详情 -->
      <div v-else-if="detailType === 'detail'" class="lx-detail-container">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="执行ID">
            {{ formData.execId || "-" }}
          </el-descriptions-item>
          <el-descriptions-item label="任务流">
            {{ formData.workflowName || "-" }}
          </el-descriptions-item>
          <el-descriptions-item label="任务名称">
            {{ formData.jobName || "-" }}
          </el-descriptions-item>

          <el-descriptions-item label="开始结束时间">
            {{ formatTime(formData.startTimestamp) }} -
            {{ formatTime(formData.endTimestamp) }}
          </el-descriptions-item>
          <el-descriptions-item label="创建人">
            {{ formData.createBy || "-" }}
          </el-descriptions-item>
          <el-descriptions-item label="解决状态">
            <el-tag
              :type="formData.solveFlag === '已解决' ? 'success' : 'danger'"
              size="small"
            >
              {{ formData.solveFlag || "待解决" }}
            </el-tag>
          </el-descriptions-item>

          <el-descriptions-item label="处理状态">
            <el-tag
              :type="formData.handleFlag === '已处理' ? 'success' : 'danger'"
              size="small"
            >
              {{ formData.handleFlag || "未处理" }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="错误类型">
            {{ formData.errorType || "-" }}
          </el-descriptions-item>

          <el-descriptions-item label="任务描述" :span="2">
            {{ formData.jobDescription || "-" }}
          </el-descriptions-item>
          <el-descriptions-item label="任务流描述" :span="2">
            {{ formData.workflowDescription || "-" }}
          </el-descriptions-item>
          <el-descriptions-item
            label="报警原因"
            :span="2"
            v-if="formData.alarmReasion"
          >
            <span class="red"> {{ formData.alarmReasion }}</span>
          </el-descriptions-item>
        </el-descriptions>
      </div>
    </div>
  </de-modal>
</template>

<script setup>
import { ref, reactive, computed, nextTick } from "vue";
import { ElMessage } from "element-plus";
import { Refresh } from "@element-plus/icons-vue";
import DeModal from "../../../components/Demodal/index.vue";
import { queryLogs, addTaskAlarm } from "../../../api/dataMonitor/taskAlarm.js";

// Emits
const emit = defineEmits(["refresh"]);

// 响应式数据
const isFullScreen = ref(false);
const visible = ref(false);
const title = ref("");
const detailType = ref("deal");
const logContent = ref("");
const loading = ref(false);
const logLoading = ref(false);

// 表单数据
const formData = ref({
  execId: "",
  workflowName: "",
  jobName: "",
  createBy: "",
  startTimestamp: "",
  endTimestamp: "",
  solveFlag: "",
  handleFlag: "",
  errorType: "",
  jobDescription: "",
  workflowDescription: "",
  alarmReasion: "",
});

const formRef = ref();

const formLog = ref();

// 表单验证规则
const formRules = reactive({
  alarmReasion: [
    { required: true, message: "请输入报警原因", trigger: "blur" },
    { min: 5, max: 500, message: "长度在 5 到 500 个字符", trigger: "blur" },
  ],
  errorType: [{ required: true, message: "请选择错误类型", trigger: "change" }],
  solveFlag: [{ required: true, message: "请选择解决状态", trigger: "change" }],
});

// 选项数据
const solveOptions = [
  { value: "已解决", label: "已解决" },
  { value: "未解决已有对策", label: "未解决已有对策" },
  { value: "未解决未有对策", label: "未解决未有对策" },
];

const errorTypeOptions = [
  { value: "平台", label: "平台" },
  { value: "doris", label: "doris" },
  { value: "源系统", label: "源系统" },
  { value: "网络", label: "网络" },
  { value: "开发Bug", label: "开发Bug" },
  { value: "其它", label: "其它" },
];

// 计算属性
const modalTitleMap = computed(() => ({
  deal: "处理任务",
  log: "查看执行日志",
  detail: "任务详情",
}));

const dialogWidth = computed(() => {
  switch (detailType.value) {
    case "deal":
      return "600px";
    case "log":
      return "80%";
    default:
      return "76%";
  }
});

const scrollHeight = computed(() => {
  return isFullScreen.value ? "calc(100vh - 160px)" : "400px";
});

// 方法
const formatTime = (time) => {
  if (!time) return "-";
  return time;
};

const resetForm = () => {
  formData.value = {
    execId: "",
    workflowName: "",
    jobName: "",
    createBy: "",
    startTimestamp: "",
    endTimestamp: "",
    solveFlag: "",
    handleFlag: "",
    errorType: "",
    jobDescription: "",
    workflowDescription: "",
    alarmReasion: "",
  };
  logContent.value = "";
  if (formRef.value) {
    formRef.value.clearValidate();
  }
};

const handleSubmit = async () => {
  if (detailType.value === "deal") {
    // 处理表单提交
    try {
      const valid = await formRef.value.validate();
      if (!valid) return;

      loading.value = true;
      await addTaskAlarm({
        execId: formData.value.execId,
        workflowName: formData.value.workflowName,
        alarmReasion: formData.value.alarmReasion,
        errorType: formData.value.errorType,
        solveFlag: formData.value.solveFlag,
        createBy: formData.value.createBy,
        jobName: formData.value.jobName,
      });

      ElMessage.success("处理成功");
      visible.value = false;
      emit("refresh");
    } catch (error) {
      console.error("处理任务失败:", error);
      ElMessage.error("处理失败，请重试");
    } finally {
      loading.value = false;
    }
  } else {
    // 其他模式直接关闭
    visible.value = false;
  }
};

const handleCancel = () => {
  visible.value = false;
  resetForm();
};

const handleQueryLog = async (row = null) => {
  const execId = row?.execId || formData.value.execId;

  if (!execId) {
    ElMessage.warning("无法查询日志：缺少执行ID");
    return;
  }

  try {
    logLoading.value = true;
    const params = {
      name: row?.jobId || formLog.value.jobId || "",
      execId: execId,
    };
    const res = await queryLogs(params);
    logContent.value = res.data || res.msg || "暂无日志内容";
    if (res.code == 200 && !row) ElMessage.success("日志刷新成功");
  } catch (error) {
    console.error("查询日志失败:", error);
    ElMessage.error("获取日志失败");
    logContent.value = "获取日志失败，请重试";
  } finally {
    logLoading.value = false;
  }
};

const show = async (row = null, type = "deal") => {
  visible.value = true;
  detailType.value = type;
  title.value = modalTitleMap.value[type] || "详情";

  resetForm();

  if (row) {
    Object.keys(formData.value).forEach((key) => {
      if (row[key] !== undefined && row[key] !== null) {
        formData.value[key] = row[key];
      }
    });
    formLog.value = JSON.parse(JSON.stringify(row));
  }

  await nextTick();

  if (type === "log") {
    const execId = row?.execId || formData.value.execId;
    if (execId) {
      handleQueryLog(row);
    }
  }
};

// 暴露方法
defineExpose({ show });
</script>

<style lang="scss" scoped>
.dialog-box {
  width: 100%;
  box-sizing: border-box;
  overflow: hidden;
  height: 100%;
}
.log-container {
  .log-header {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    margin-bottom: 16px;

    h4 {
      margin: 0;
      color: #303133;
    }
  }

  .log-content {
    border-radius: 4px;
    border: 1px solid #ebeef5;
    background-color: #f7f9fc;

    .log-text {
      margin: 0;
      padding: 16px;
      font-family: "Monaco", "Menlo", "Ubuntu Mono", monospace;
      font-size: 12px;
      line-height: 1.5;
      color: #333;
      white-space: pre-wrap;
      word-break: break-all;
    }

    .empty-log {
      padding: 40px 0;
    }
  }
}

</style>
