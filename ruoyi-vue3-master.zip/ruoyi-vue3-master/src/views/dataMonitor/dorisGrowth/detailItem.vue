<template>
  <de-modal
    :title="title"
    v-model:visible="visible"
    width="900px"
    :showFooter="false"
  >
    <div class="lx-detail-container">
      <el-descriptions :column="2" border>
        <el-descriptions-item label="日期：">
          {{ formData.dbDate || "-" }}
        </el-descriptions-item>
        <el-descriptions-item label="chema">
          {{ formData.tableSchema || "-" }}
        </el-descriptions-item>
        <el-descriptions-item label="表名">
          {{ formData.tableName || "-" }}
        </el-descriptions-item>

        <el-descriptions-item label="表类型">
          {{ formData.tableType }}
        </el-descriptions-item>
        <el-descriptions-item label="创建时间">
          {{ formData.createTime || "-" }}
        </el-descriptions-item>
        <el-descriptions-item label="更新时间">
          {{ formData.updateTime || "-" }}
        </el-descriptions-item>
        <el-descriptions-item label="当前表总容量 (GB)">
          {{ formData.dataLength0 }}
        </el-descriptions-item>
        <el-descriptions-item label="7日均增量 (GB)">
          {{ formData.avgDataLength }}
        </el-descriptions-item>
        <el-descriptions-item label="新增数据大小 (GB)">
        <span :class="{ 'red-b': formData.flag1 === 'Y' }">{{ formData.dataLengthI1 }}</span>  
        </el-descriptions-item>
        <el-descriptions-item label="day-1增量 (行数)">
          {{ formData.tableRowsI1 }}
        </el-descriptions-item>
        <el-descriptions-item label="day增量 (GB)">
        <span :class="{ 'red-b': formData.flag2 === 'Y' }">{{ formData.dataLengthI0 }}</span>  
        </el-descriptions-item>
        <el-descriptions-item label="day增量(行数)">
          {{ formData.tableRowsI0 }}
        </el-descriptions-item>
        <el-descriptions-item label="表注释">
          {{ formData.tableComment || "-" }}
        </el-descriptions-item>
      </el-descriptions>
    </div>
  </de-modal>
</template>

<script setup>
import { ref, reactive, computed, nextTick } from "vue";
import DeModal from "../../../components/Demodal/index.vue";
const visible = ref(false);
const title = ref("");
const formData = ref({
  tableName: "",
  dataLength0: "",
  avgDataLength: "",
  dataLengthI1: "",
  tableRowsI1: "",
  dataLengthI0: "",
  tableRowsI0: "",
  dbDate: "",
});

const show = (row) => {
  visible.value = true;
  title.value = "详情";
  if (row) {
    formData.value = JSON.parse(JSON.stringify(row));
  }
};

// 暴露方法
defineExpose({ show });
</script>

<style lang="sass" scoped></style>
