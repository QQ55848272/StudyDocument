<template>
  <div class="app-container">
    <div class="lx-search-bar" v-show="showSearch">
      <el-form
        ref="queryFormRef"
        :model="queryParams"
        :inline="true"
        label-position="top"
      >
        <el-form-item label="层级">
          <el-select
            v-model="queryParams.tableSchema"
            placeholder="请选择"
            clearable
            @change="handleSearch"
          >
            <el-option
              v-for="item in ['ods', 'dwd', 'dws', 'ads', 'test']"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="排名数量">
          <el-input-number
            :step="5"
            v-model.trim="queryParams.limit"
            placeholder="请输入排名数量"
            clearable
            @keyup.enter="handleSearch"
            @change="handleSearch"
          />
        </el-form-item>
        <el-form-item label="日期">
          <el-date-picker
            v-model="queryParams.queryDate"
            type="date"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
          />
        </el-form-item>
        <el-form-item class="form-actions">
          <el-button
            type="primary"
            :icon="Search"
            @click="handleSearch"
            :loading="loading"
          >
            搜索
          </el-button>
          <!-- <el-button :icon="Refresh" @click="handleReset">重置</el-button> -->
        </el-form-item>
      </el-form>
    </div>
    <div class="lx-tool">
      <span class="total"> 表空间监控排名 </span>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="handleSearch"
      ></right-toolbar>
    </div>
    <div class="lx-table-container">
      <el-table
        max-height="480px"
        :data="tableData"
        v-loading="loading"
        style="width: 100%"
        :header-cell-style="tableHeaderStyle"
        :cell-style="tableCellStyle"
        border
        show-summary
      >
        <!-- 加索引 -->

        <el-table-column
          type="index"
          label="排名"
          width="100"
          align="center"
          fixed="left"
        />

        <el-table-column
          prop="tableName"
          label="表名"
          min-width="260"
          align="left"
        />

        <el-table-column
          prop="dataLength0"
          label="当前表总容量(GB)"
          width="180"
          align="center"
          sortable
        >
          <template #default="{ row }">
            <span>{{ Number(row.dataLength0).toFixed(3) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="avgDataLength"
          label="7日均增量(GB)"
          width="180"
          align="center"
          sortable
        >
          <template #default="{ row }">
            <span>{{ row.avgDataLength.toFixed(3) }}</span>
          </template>
        </el-table-column>

        <el-table-column
          prop="dataLengthI1"
          label="day-1 增量 (GB)"
          width="180"
          align="center"
          sortable
        >
          <template #default="{ row }">
            <span>{{ Number(row.dataLengthI1).toFixed(3) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="tableRowsI1"
          label="day-1增量 (行数)"
          width="180"
          align="center"
          sortable
        />

        <el-table-column
          prop="dataLengthI0"
          label="day增量 (GB)"
          width="180"
          align="center"
          sortable
        >
          <template #default="{ row }">
            <span>{{ Number(row.dataLengthI0).toFixed(3) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="tableRowsI0"
          label="day增量(行数)"
          width="180"
          align="center"
          sortable
        />

        <el-table-column label="详情" width="160" align="center" fixed="right">
          <template #default="{ row }">
            <el-button
              type="primary"
              link
              size="small"
              @click="handleViewDetail(row)"
            >
              查看
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 详情 -->
    <DetailDialog ref="DetailDialogRefs"></DetailDialog>
  </div>
</template>

<script name="dorisGrowth" setup>
import { ref, reactive, onMounted, computed } from "vue";
import { ElMessage } from "element-plus";
import { Search, Refresh } from "@element-plus/icons-vue";
import { listDorisGrowth } from "../../../api/dataMonitor/dorisGrowth.js";
import DetailDialog from "./detailItem.vue";
const queryFormRef = ref(null);
const loading = ref(false);
const tableData = ref([]);
const showSearch = ref(true);
const DetailDialogRefs = ref(null);

const queryParams = reactive({
  queryDate: "",
  tableSchema: "",
  limit: 10,
});

const tableHeaderStyle = {
  fontSize: "14px",
  textAlign: "center",
  fontWeight: "bold",
  backgroundColor: "#F7F9FC",
  color: "#1F2E4D",
};

const handleSearch = async () => {
  try {
    loading.value = true;
    const Params = { ...queryParams };
    const response = await listDorisGrowth(Params);
    tableData.value = response.data;
  } catch (error) {
    ElMessage.error("获取数据失败，请重试");
    tableData.value = [];
  } finally {
    loading.value = false;
  }
};

const handleViewDetail = (row) => {
  console.log(row);
  DetailDialogRefs.value.show(row);
};

const tableCellStyle = ({ row, column }) => {
  if (column.property === "dataLengthI1" && row.flag1 === "Y") {
    return {
      color: "#ed435a",
      backgroundColor: "#fff6f6",
      fontWeight: 500,
    };
  } else if (column.property === "dataLengthI0" && row.flag2 === "Y") {
    return {
      color: "#ed435a",
      fontWeight: 500,
      backgroundColor: "#fff6f6",
    };
  } else {
    return {};
  }
};

const handleReset = () => {
  // 重置表单
  if (queryFormRef.value) {
    queryFormRef.value.resetFields();
  }
  Object.keys(queryParams).forEach((key) => {
    queryParams[key] = "";
  });
  handleSearch();
};

onMounted(() => {
  const now = new Date();
  queryParams.queryDate = `${now.getFullYear()}-${String(
    now.getMonth() + 1
  ).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  handleSearch();
});
</script>

<style lang="sass" scoped></style>
