<template>
  <div class="app-container">
    <div class="lx-search-bar" v-if="showSearch">
      <el-form
        ref="queryFormRef"
        :model="queryParams"
        :inline="true"
        label-position="top"
      >
        <el-form-item label="执行账号">
          <el-select
            v-model="queryParams.user"
            placeholder="请选择执行账号"
            filterable
            clearable
            @change="handleSearch"
          >
            <el-option
              v-for="item in userOptions"
              :key="item.label"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="执行结果">
          <el-select
            v-model="queryParams.state"
            placeholder="请选择执行结果"
            filterable
            clearable
            @change="handleSearch"
          >
            <el-option
              v-for="item in stateOptions"
              :key="item.label"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="日期范围">
          <el-date-picker
            v-model="timeRange"
            type="datetimerange"
            align="right"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :default-time="[
              new Date(new Date().setHours(0, 0, 0, 0)),
              new Date(new Date().setHours(23, 59, 59, 999)),
            ]"
            format="YYYY-MM-DD HH:mm:ss"
            value-format="YYYY-MM-DD HH:mm:ss"
            @change="handleTimeRangeChange"
          />
        </el-form-item>
        <el-form-item label="排名数量">
          <el-input-number
            :step="5"
            :min="10"
            v-model.trim="queryParams.limit"
            placeholder="请输入排名数量"
            clearable
            @keyup.enter="handleSearch"
            @change="handleSearch"
          />
        </el-form-item>
        <el-form-item class="form-actions">
          <el-button
            type="primary"
            :icon="Search"
            @click="handleSearch"
            :loading="loading"
          >
            搜索
          </el-button>
          <right-toolbar
            v-model:showSearch="showSearch"
            @queryTable="handleSearch"
          ></right-toolbar>
        </el-form-item>
      </el-form>
    </div>
    <div class="lx-tool" v-else>
      <span class="total"></span>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="handleSearch"
      ></right-toolbar>
    </div>
    <div class="lx-table-container">
      <el-table
        max-height="510px"
        :data="tableData"
        v-loading="loading"
        style="width: 100%"
        :header-cell-style="tableHeaderStyle"
        :preserve-expanded-content="false"
        border
        show-summary
      >
        <el-table-column
          type="index"
          label="排名"
          width="100"
          align="center"
          fixed="left"
        />
        <el-table-column
          prop="user"
          label="用户名"
          min-width="140"
          align="center"
        />

        <el-table-column
          prop="stmt"
          label="执行SQL"
          min-width="300"
          align="left"
        >
          <template #default="{ row }">
            <div class="stmt-cell">
              <span class="stmt-text"> {{ row.stmt }}</span>
              <span class="stmt-icon" @click="handleViewStmt(row.stmt)"
                ><el-icon><View /></el-icon
              ></span>
              <span class="stmt-icon" @click="handleCopyStmt(row.stmt)"
                ><el-icon><CopyDocument /></el-icon
              ></span>
            </div>
          </template>
        </el-table-column>
        <!-- <el-table-column type="expand">
          <template #default="props">
            <div>{{ props.row.stmt }}</div>
          </template>
        </el-table-column> -->

        <el-table-column
          prop="state"
          label="直接结果"
          min-width="120"
          align="center"
        />
        <el-table-column prop="cpuTimeMin" min-width="150" align="center">
          <template #header>
            <div class="table-head-cw">
              <span>CPU耗时</span><br />
              <span class="table-head-f12">(汇总 MIN)</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="queryTimeMin" min-width="150" align="center">
          <template #header>
            <div class="table-head-cw">
              <span>查询耗时</span><br />
              <span class="table-head-f12">(汇总 MIN)</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="memoryMegabyte" min-width="150" align="center">
          <template #header>
            <div class="table-head-cw">
              <span>内存占用</span><br />
              <span class="table-head-f12">(汇总)</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="avgQueryTimeMin" min-width="150" align="center">
          <template #header>
            <div class="table-head-cw">
              <span>CPU耗时</span><br />
              <span class="table-head-f12">(均值 MIN)</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="avgMemoryMegabyte"
          min-width="150"
          align="center"
        >
          <template #header>
            <div class="table-head-cw">
              <span>查询耗时</span><br />
              <span class="table-head-f12">(汇总 GB)</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="avgCPUNum" min-width="160" align="center">
          <template #header>
            <div class="table-head-cw">
              <span>CPU使用</span><br />
              <span class="table-head-f12">(均值 核数)</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="useTimes"
          label="执行次数"
          min-width="120"
          align="center"
        />
        <el-table-column label="详情" width="150" align="center" fixed="right">
          <template #default="{ row }">
            <el-button
              type="primary"
              link
              size="small"
              @click="handleViewDetail(row)"
            >
              查看
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <DetailDialog ref="DetailDialogRefs"></DetailDialog>
  </div>
</template>

<script name="DorisSql" setup>
import { ref, onMounted } from "vue";
import dayjs from "dayjs";
import { ElMessage } from "element-plus";
import DetailDialog from "./detailItem.vue";
import { Search, Refresh, View, CopyDocument } from "@element-plus/icons-vue";
import { listSlowSql, dorisUser } from "../../../api/dorisSql/index.js";

const timeRange = ref([]);
const queryFormRef = ref();
const loading = ref(false);
const showSearch = ref(true);
const tableData = ref([]);
const userOptions = ref([]);
const DetailDialogRefs = ref(null);

const stateOptions = [
  { label: "ALL", value: "" },
  { label: "OK", value: "OK" },
  { label: "EOF", value: "EOF" },
  { label: "ERR", value: "ERR" },
];

const queryParams = reactive({
  startTime: "",
  endTime: "",
  user: "",
  state: "",
  limit: 10,
});

const tableHeaderStyle = {
  fontSize: "14px",
  textAlign: "center",
  fontWeight: "bold",
  color: "#1F2E4D",
};

const dorisUserQuery = async () => {
  try {
    const response = await dorisUser();
    userOptions.value = response.data.map((item) => ({
      label: item.username,
      value: item.username,
    }));
  } catch (error) {
    ElMessage.error("获取数据失败，请重试");
  }
};
dorisUserQuery();

const handleSearch = async () => {
  try {
    loading.value = true;
    const Params = { ...queryParams };
    const response = await listSlowSql(Params);
    tableData.value = response.data;
  } catch (error) {
    ElMessage.error("获取数据失败，请重试");
    tableData.value = [];
  } finally {
    loading.value = false;
  }
};

const handleViewDetail = (row) => {
  const params = {
    startTime: queryParams.startTime,
    endTime: queryParams.endTime,
    state: row.state,
    stmt: row.stmt,
  };
  DetailDialogRefs.value.show(params, "detail");
};

const handleViewStmt = (stmt) => {
  DetailDialogRefs.value.show(stmt, "sql");
};

const handleCopyStmt = async (stmt) => {
  if (!stmt) {
    ElMessage.error("请先选择一条数据");
    return;
  }

  try {
    // 方法1: 使用现代 Clipboard API (首选)
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(stmt);
      ElMessage.success("复制成功");
      return;
    }

    // 方法2: 使用传统的 execCommand 作为备选
    const textArea = document.createElement("textarea");
    textArea.value = stmt;
    textArea.style.position = "fixed";
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.width = "2em";
    textArea.style.height = "2em";
    textArea.style.padding = "0";
    textArea.style.border = "none";
    textArea.style.outline = "none";
    textArea.style.boxShadow = "none";
    textArea.style.background = "transparent";
    textArea.style.opacity = "0";

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    const successful = document.execCommand("copy");
    document.body.removeChild(textArea);

    if (successful) {
      ElMessage.success("复制成功");
    } else {
      throw new Error("execCommand failed");
    }
  } catch (err) {
    console.error("复制失败:", err);
  }
};

const handleTimeRangeChange = (value) => {
  if (value && value.length === 2) {
    queryParams.startTime = value[0];
    queryParams.endTime = value[1];
  } else {
    queryParams.startTime = "";
    queryParams.endTime = "";
  }
};

onMounted(() => {
  const now = new Date();
  timeRange.value[0] = `${now.getFullYear()}-${String(
    now.getMonth() + 1
  ).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")} 00:00:00`;
  timeRange.value[1] = dayjs().format("YYYY-MM-DD HH:mm:ss");
  queryParams.startTime = timeRange.value[0];
  queryParams.endTime = timeRange.value[1];
  handleSearch();
});
</script>

<style lang="scss" scoped>
.stmt-cell {
  width: 100%;
  display: flex;
  justify-content: space-between;
  gap: 8px;
  align-items: center;
  .stmt-text {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 190px;
    display: inline-block;
  }
  .stmt-icon {
    cursor: pointer;
    display: flex;
    width: 22px;
    height: 22px;
    color: #1f2e4d;
    font-weight: bold;
    // background-color: #ecf5ff;
    border-radius: 4px;
    align-items: center;
    justify-content: center;

    &:hover {
      color: #409eff;
      background-color: #ecf5ff;
    }
  }
}
</style>
