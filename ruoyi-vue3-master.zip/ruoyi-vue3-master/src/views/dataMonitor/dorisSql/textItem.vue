<template>
  <de-modal
    :title="title"
    v-model:visible="visible"
    :width="dialogWidth"
    :showFooter="false"
    v-model:isFullScreen="isFullScreen"
  >
    <div class="lx-detail-container">
      <div class="log-container">
        <div class="log-content">
          <el-scrollbar :style="{ height: scrollHeight }">
            <p v-if="Content" class="log-text">{{ Content }}</p>
          </el-scrollbar>
        </div>
      </div>
    </div>
  </de-modal>
</template>

<script setup>
import { ref, reactive, computed, nextTick } from "vue";
import DeModal from "../../../components/Demodal/index.vue";
const visible = ref(false);
const title = ref("");
const Content = ref("");
const isFullScreen = ref(false);

const scrollHeight = computed(() => {
  return isFullScreen.value ? "calc(100vh - 160px)" : "400px";
});

const show = (txt, type = "sql") => {
  visible.value = true;
  if (type === "sql") {
    title.value = "执行SQL详情";
  } else {
    title.value = "报错信息";
  }
  Content.value = txt;
};

// 暴露方法
defineExpose({ show });
</script>

<style lang="scss" scoped>
.log-container {
  .log-content {
    border-radius: 4px;
    border: 1px solid #ebeef5;
    background-color: #f7f9fc;

    .log-text {
      margin: 0;
      padding: 16px;
      font-family: "Monaco", "Menlo", "Ubuntu Mono", monospace;
      font-size: 14px;
      line-height: 1.5;
      color: #333;
      white-space: pre-wrap;
      word-break: break-all;
    }

    .empty-log {
      padding: 40px 0;
    }
  }
}
</style>
