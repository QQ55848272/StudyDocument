<template>
  <de-modal
    :title="title"
    v-model:visible="visible"
    :width="dialogWidth"
    :showFooter="false"
    v-model:isFullScreen="isFullScreen"
  >
    <div class="lx-detail-container">
      <div v-if="detailType === 'sql'" class="log-container">
        <div class="log-content">
          <el-scrollbar :style="{ height: scrollHeight }">
            <p v-if="sqlContent" class="log-text">{{ sqlContent }}</p>
          </el-scrollbar>
        </div>
      </div>
      <template v-else>
        <div class="lx-table-container">
          <el-table
            :data="sqlTable"
            v-loading="loading"
            style="width: 100%"
            border
            stripe
            :preserve-expanded-content="true"
            :height="scrollHeight2"
          >
            <el-table-column
              type="index"
              label="NO"
              width="100"
              align="center"
              fixed="left"
            />
            <el-table-column type="expand">
              <template #default="{ row }">
                <div class="log-container">
                  <el-scrollbar class="log-content">
                    <p v-if="row.stmt" class="log-text">
                      <b>执行SQL：</b>{{ row.stmt }}
                    </p>
                    <hr />
                    <p v-if="row.errorMessage" class="log-text">
                      <b>报错信息：</b> {{ row.errorMessage }}
                    </p>
                  </el-scrollbar>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="time"
              label="执行时间"
              width="180"
              align="center"
            />
            <el-table-column
              prop="clientIp"
              label="客户端IP"
              width="180"
              align="center"
            />
            <el-table-column
              prop="user"
              label="用户名"
              width="180"
              align="center"
            />
            <el-table-column
              prop="stmt"
              label="执行SQL"
              width="300"
              align="center"
            >
              <template #default="{ row }">
                <div class="stmt-cell">
                  <span class="stmt-text">{{ row.stmt }}</span>
                  <span class="stmt-icon" @click="handleView(row.stmt, 'sql')"
                    ><el-icon><View /></el-icon
                  ></span>
                  <span class="stmt-icon" @click="handleCopy(row.stmt)"
                    ><el-icon><CopyDocument /></el-icon
                  ></span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="state"
              label="执行结果"
              width="120"
              align="center"
            />
            <el-table-column
              prop="errorMessage"
              label="报错信息"
              width="300"
              align="center"
            >
              <template #default="{ row }">
                <div class="stmt-cell" v-if="row.errorMessage">
                  <span class="stmt-text"> {{ row.errorMessage }}</span>
                  <span
                    class="stmt-icon"
                    @click="handleView(row.errorMessage, 'err')"
                    ><el-icon><View /></el-icon
                  ></span>
                  <span class="stmt-icon" @click="handleCopy(row.errorMessage)"
                    ><el-icon><CopyDocument /></el-icon
                  ></span>
                </div>
              </template>
            </el-table-column>

            <el-table-column
              prop="cpuTimeMin"
              label="CPU耗时(min)"
              width="140"
              align="center"
            />
            <el-table-column
              prop="queryTimeMin"
              label="查询时间按（min）"
              width="140"
              align="center"
            />
            <el-table-column
              prop="memoryMegabyte"
              label="内存使用(GB )"
              width="140"
              align="center"
            />
            <el-table-column
              prop="cpuNum"
              label="CPU使用(核数)"
              width="140"
              align="center"
            />
            <el-table-column
              prop="scanRows"
              label="查询笔数"
              width="140"
              align="center"
            />
            <el-table-column
              prop="returnRows"
              label="返回笔数"
              width="140"
              align="center"
            />
          </el-table>
        </div>
        <div class="lx-pagination-container">
          <el-pagination
            hide-on-single-page
            v-model:current-page="pagination.pageNum"
            v-model:page-size="pagination.pageSize"
            :page-sizes="[10, 20, 50, 100]"
            :total="pagination.total"
            layout="total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </template>

      <TextItem ref="textItemRefs"></TextItem>
    </div>
  </de-modal>
</template>

<script setup>
import { ref, reactive, computed, nextTick } from "vue";
import { ElMessage } from "element-plus";
import DeModal from "../../../components/Demodal/index.vue";
import { detailsSlowSql } from "../../../api/dorisSql/index.js";
import TextItem from "./textItem.vue";

const textItemRefs = ref(null);
const visible = ref(false);
const title = ref("");
const detailType = ref("sql");
const sqlContent = ref("");
const isFullScreen = ref(false);
const sqlTable = ref([]);
const loading = ref(false);
const paramsData = ref({});
const pagination = reactive({
  total: 0,
  pageNum: 1,
  pageSize: 10,
});

const scrollHeight = computed(() => {
  return isFullScreen.value ? "calc(100vh - 160px)" : "400px";
});

const scrollHeight2 = computed(() => {
  return isFullScreen.value ? "calc(100vh - 240px)" : "440px";
});
const dialogWidth = computed(() => {
  switch (detailType.value) {
    case "sql":
      return "800px";
    default:
      return "90%";
  }
});
const show = (row = null, type = "sql") => {
  visible.value = true;
  detailType.value = type;
  if (type === "sql") {
    title.value = "执行SQL详情";
    sqlContent.value = row;
  } else {
    title.value = "执行结果明细";
    paramsData.value = row;

    queryDetail();
  }
};

const queryDetail = async () => {
  try {
    loading.value = true;
    const Params = {
      ...paramsData.value,
      pageNum: pagination.pageNum,
      pageSize: pagination.pageSize,
    };
    const res = await detailsSlowSql(Params);
    loading.value = false;
    sqlTable.value = res.data.list;
    pagination.total = res.data.total;
  } catch (error) {
    loading.value = false;
    ElMessage.error("获取数据失败，请重试");
  }
};

const handleSizeChange = (newSize) => {
  pagination.pageSize = newSize;
  pagination.pageNum = 1;
  queryDetail();
};

const handleCurrentChange = (newPage) => {
  pagination.pageNum = newPage;
  queryDetail();
};

const handleView = (text, type) => {
  textItemRefs.value.show(text, type);
};

const handleCopy = async (text) => {
  try {
    // 方法1: 使用现代 Clipboard API (首选)
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      ElMessage.success("复制成功");
      return;
    }

    // 方法2: 使用传统的 execCommand 作为备选
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.width = "2em";
    textArea.style.height = "2em";
    textArea.style.padding = "0";
    textArea.style.border = "none";
    textArea.style.outline = "none";
    textArea.style.boxShadow = "none";
    textArea.style.background = "transparent";
    textArea.style.opacity = "0";

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    const successful = document.execCommand("copy");
    document.body.removeChild(textArea);

    if (successful) {
      ElMessage.success("复制成功");
    } else {
      throw new Error("execCommand failed");
    }
  } catch (err) {
    console.error("复制失败:", err);
  }
};

// 暴露方法
defineExpose({ show });
</script>

<style lang="scss" scoped>
.stmt-cell {
  width: 100%;
  display: flex;
  justify-content: space-between;
  gap: 8px;
  align-items: center;
  .stmt-text {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 190px;
    display: inline-block;
  }
  .stmt-icon {
    cursor: pointer;
    display: flex;
    width: 22px;
    height: 22px;
    color: #1f2e4d;
    font-weight: bold;
    // background-color: #ecf5ff;
    border-radius: 4px;
    align-items: center;
    justify-content: center;

    &:hover {
      color: #409eff;
      background-color: #ecf5ff;
    }
  }
}
.log-container {
  .log-content {
    border-radius: 4px;
    border: 1px solid #ebeef5;
    background-color: #f7f9fc;

    .log-text {
      margin: 0;
      padding: 16px;
      font-family: "Monaco", "Menlo", "Ubuntu Mono", monospace;
      font-size: 14px;
      line-height: 1.5;
      color: #333;
      white-space: pre-wrap;
      word-break: break-all;
    }

    .empty-log {
      padding: 40px 0;
    }
  }
}
</style>
