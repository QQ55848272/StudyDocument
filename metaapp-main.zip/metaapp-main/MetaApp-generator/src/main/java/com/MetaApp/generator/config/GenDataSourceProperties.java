package com.MetaApp.generator.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "gen")
public class GenDataSourceProperties {
    private List<GenDatasource> datasources;

    @Data
    public static class GenDatasource {
        private String name;
        private String url;
        private String username;
        private String password;
    }
}
