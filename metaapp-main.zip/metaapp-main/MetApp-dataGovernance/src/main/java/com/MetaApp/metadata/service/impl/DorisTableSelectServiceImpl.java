package com.MetaApp.metadata.service.impl;

import com.MetaApp.metadata.domain.DorisTableSelect;
import com.MetaApp.metadata.mapper.DorisTableSelectMapper;
import com.MetaApp.metadata.service.DorisTableSelectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DorisTableSelectServiceImpl implements DorisTableSelectService {
    @Autowired
    private DorisTableSelectMapper mapper;
    @Override
    public List<DorisTableSelect> selectDorisTableList(DorisTableSelect filter) {
        return mapper.selectDorisTableList(filter);
    }

    @Override
    public List<String> selectAllSchemas() {
        return mapper.selectAllSchemas();
    }
}
