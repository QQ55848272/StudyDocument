package com.MetaApp.metadata.service;

import com.MetaApp.metadata.domain.SchemaTable;
import com.MetaApp.metadata.domain.SiteTable;
import com.MetaApp.metadata.domain.TableNameTable;
import com.MetaApp.metadata.mapper.MetaDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MetaDataService {
    @Autowired
    private MetaDataMapper metaDataMapper;

    public List<SiteTable> getSiteMapper() {
        return metaDataMapper.getSiteTables();
    }

    public List<SchemaTable> getSchemaMapper() {
        return metaDataMapper.getSchemaTables();
    }
    public List<TableNameTable> getTableNameMapper() {
        return metaDataMapper.getTableNamesTables();
    }

}
