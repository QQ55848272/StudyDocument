package com.MetaApp.doris.service.Impl;

import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.doris.domain.DorisTableGrowthVO;
import com.MetaApp.doris.mapper.DorisTableGrowthMapper;
import com.MetaApp.doris.service.IDorisTableGrowthService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DorisTableGrowthServiceImpl implements IDorisTableGrowthService {

    private final DorisTableGrowthMapper dorisTableGrowthMapper;

    public DorisTableGrowthServiceImpl(DorisTableGrowthMapper dorisTableGrowthMapper) {
        this.dorisTableGrowthMapper = dorisTableGrowthMapper;
    }

    @Override
    @DataSource(value= DataSourceType.SLAVE)
    public List<DorisTableGrowthVO> selectDorisTableGrowth(String queryDate, String tableSchema, Integer limit) {
        return dorisTableGrowthMapper.selectDorisTableGrowth(queryDate, tableSchema, limit);
    }
}
