package com.MetaApp.metadata.service;

import com.MetaApp.metadata.domain.DorisTableSelect;

import java.util.List;

public interface DorisTableSelectService {
    List<DorisTableSelect> selectDorisTableList(DorisTableSelect filter);
    List<String> selectAllSchemas();
}
