package com.MetaApp.hdsp.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmVO;
import com.MetaApp.hdsp.service.IHdspMonitorTaskAlarmService;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/hdsp/taskAlarm")
public class HdspMonitorTaskAlarmController {

    @Resource
    private IHdspMonitorTaskAlarmService taskAlarmService;

    @GetMapping("/list")
    public AjaxResult list(
            @RequestParam(required = false) Long execId,
            @RequestParam(required = false) String workflowName,
            @RequestParam(required = false) String jobName,
            @RequestParam(required = false) String realName,
            @RequestParam(required = false)
            @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
            Date startTime,
            @RequestParam(required = false)
            @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
            Date endTime,
            @RequestParam(required = false)
            String handleFlag,
            @RequestParam(required = false) String solveFlag,
            @RequestParam(required = false) String errorType,
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize

    ) {
        // 开始分页
        PageHelper.startPage(pageNum, pageSize);
        List<HdspMonitorTaskAlarmVO> list = taskAlarmService.selectTaskAlarmList(
                execId, workflowName, jobName, realName, startTime, endTime, handleFlag, solveFlag, errorType);

        // 封装分页信息
        PageInfo<HdspMonitorTaskAlarmVO> pageInfo = new PageInfo<>(list);
        return AjaxResult.success(pageInfo);
    }
}
