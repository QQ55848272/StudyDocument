package com.MetaApp.hdsp.service;

public interface IExecutionLogService {

    /**
     * 根据 exec_id 和 name 查询日志（自动解析 longblob 为字符串）
     * @param execId 执行ID
     * @param name 名称模糊匹配
     * @return 日志内容（字符串）
     */
    String getExecutionLog(Long execId, String name);
}
