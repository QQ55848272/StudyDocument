package com.MetaApp.metadata.service.impl;

import com.MetaApp.metadata.domain.DorisAllTableInfomation;
import com.MetaApp.metadata.mapper.DorisAllTableInfomationMapper;
import com.MetaApp.metadata.service.DorisAllTableInfomationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DorisAllTableInfomationServiceImpl implements DorisAllTableInfomationService {
    @Autowired
    private DorisAllTableInfomationMapper mapper;

    @Override
    public List<DorisAllTableInfomation> selectDorisTableList(DorisAllTableInfomation filter) {
        return mapper.selectDorisTableList(filter);
    }

    @Override
    public List<String> selectAllSchemas() {
        return mapper.selectAllSchemas();
    }
}
