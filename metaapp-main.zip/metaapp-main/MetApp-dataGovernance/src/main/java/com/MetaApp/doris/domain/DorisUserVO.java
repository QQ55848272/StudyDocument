package com.MetaApp.doris.domain;

import lombok.Data;

@Data
public class DorisUserVO {
    private String username;
}
