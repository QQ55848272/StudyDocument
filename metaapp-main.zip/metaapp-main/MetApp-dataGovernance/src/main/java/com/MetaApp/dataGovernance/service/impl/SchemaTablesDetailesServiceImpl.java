package com.MetaApp.dataGovernance.service.impl;

import java.util.List;
import com.MetaApp.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.MetaApp.dataGovernance.mapper.SchemaTablesDetailesMapper;
import com.MetaApp.dataGovernance.domain.SchemaTablesDetailes;
import com.MetaApp.dataGovernance.service.ISchemaTablesDetailesService;

/**
 * schema下包含信息Service业务层处理
 * 
 * @author meta
 * @date 2025-04-13
 */
@Service
public class SchemaTablesDetailesServiceImpl implements ISchemaTablesDetailesService 
{
    @Autowired
    private SchemaTablesDetailesMapper schemaTablesDetailesMapper;

    /**
     * 查询schema下包含信息
     * 
     * @param id schema下包含信息主键
     * @return schema下包含信息
     */
    @Override
    public SchemaTablesDetailes selectSchemaTablesDetailesById(Long id)
    {
        return schemaTablesDetailesMapper.selectSchemaTablesDetailesById(id);
    }

    /**
     * 查询schema下包含信息列表
     * 
     * @param schemaTablesDetailes schema下包含信息
     * @return schema下包含信息
     */
    @Override
    public List<SchemaTablesDetailes> selectSchemaTablesDetailesList(SchemaTablesDetailes schemaTablesDetailes)
    {
        return schemaTablesDetailesMapper.selectSchemaTablesDetailesList(schemaTablesDetailes);
    }

    /**
     * 新增schema下包含信息
     * 
     * @param schemaTablesDetailes schema下包含信息
     * @return 结果
     */
    @Override
    public int insertSchemaTablesDetailes(SchemaTablesDetailes schemaTablesDetailes)
    {
        schemaTablesDetailes.setCreateTime(DateUtils.getNowDate());
        return schemaTablesDetailesMapper.insertSchemaTablesDetailes(schemaTablesDetailes);
    }

    /**
     * 修改schema下包含信息
     * 
     * @param schemaTablesDetailes schema下包含信息
     * @return 结果
     */
    @Override
    public int updateSchemaTablesDetailes(SchemaTablesDetailes schemaTablesDetailes)
    {
        schemaTablesDetailes.setUpdateTime(DateUtils.getNowDate());
        return schemaTablesDetailesMapper.updateSchemaTablesDetailes(schemaTablesDetailes);
    }

    /**
     * 批量删除schema下包含信息
     * 
     * @param ids 需要删除的schema下包含信息主键
     * @return 结果
     */
    @Override
    public int deleteSchemaTablesDetailesByIds(Long[] ids)
    {
        return schemaTablesDetailesMapper.deleteSchemaTablesDetailesByIds(ids);
    }

    /**
     * 删除schema下包含信息信息
     * 
     * @param id schema下包含信息主键
     * @return 结果
     */
    @Override
    public int deleteSchemaTablesDetailesById(Long id)
    {
        return schemaTablesDetailesMapper.deleteSchemaTablesDetailesById(id);
    }
}
