package com.MetaApp.metadata.mapper;

import com.MetaApp.metadata.domain.TableNameTable;
import com.MetaApp.metadata.domain.SchemaTable;
import com.MetaApp.metadata.domain.SiteTable;

import java.util.List;

public interface MetaDataMapper {
    public List<SiteTable> getSiteTables();
    public List<SchemaTable> getSchemaTables();
    public List<TableNameTable> getTableNamesTables();
}
