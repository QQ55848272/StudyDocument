package com.MetaApp.dataGovernance.service;

import java.util.List;
import com.MetaApp.dataGovernance.domain.SchemaTablesDetailes;

/**
 * schema下包含信息Service接口
 * 
 * @author meta
 * @date 2025-04-13
 */
public interface ISchemaTablesDetailesService 
{
    /**
     * 查询schema下包含信息
     * 
     * @param id schema下包含信息主键
     * @return schema下包含信息
     */
    public SchemaTablesDetailes selectSchemaTablesDetailesById(Long id);

    /**
     * 查询schema下包含信息列表
     * 
     * @param schemaTablesDetailes schema下包含信息
     * @return schema下包含信息集合
     */
    public List<SchemaTablesDetailes> selectSchemaTablesDetailesList(SchemaTablesDetailes schemaTablesDetailes);

    /**
     * 新增schema下包含信息
     * 
     * @param schemaTablesDetailes schema下包含信息
     * @return 结果
     */
    public int insertSchemaTablesDetailes(SchemaTablesDetailes schemaTablesDetailes);

    /**
     * 修改schema下包含信息
     * 
     * @param schemaTablesDetailes schema下包含信息
     * @return 结果
     */
    public int updateSchemaTablesDetailes(SchemaTablesDetailes schemaTablesDetailes);

    /**
     * 批量删除schema下包含信息
     * 
     * @param ids 需要删除的schema下包含信息主键集合
     * @return 结果
     */
    public int deleteSchemaTablesDetailesByIds(Long[] ids);

    /**
     * 删除schema下包含信息信息
     * 
     * @param id schema下包含信息主键
     * @return 结果
     */
    public int deleteSchemaTablesDetailesById(Long id);
}
