package com.MetaApp.metadata.mapper;

import com.MetaApp.metadata.domain.DorisTableColumnDetails;

import java.util.List;

public interface DorisTableColumnDetailsMapper {
    List<DorisTableColumnDetails> getDorisTableColumnDetails(DorisTableColumnDetails filter);
}
