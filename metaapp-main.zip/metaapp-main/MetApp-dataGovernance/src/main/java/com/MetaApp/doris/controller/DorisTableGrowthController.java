package com.MetaApp.doris.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.doris.domain.DorisTableGrowthVO;
import com.MetaApp.doris.service.IDorisTableGrowthService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/doris/dorisGrowth")
public class DorisTableGrowthController {

    private final IDorisTableGrowthService dorisTableGrowthService;

    public DorisTableGrowthController(IDorisTableGrowthService dorisTableGrowthService) {
        this.dorisTableGrowthService = dorisTableGrowthService;
    }

    /**
     * 查询 Doris 表增长情况
     */
    @GetMapping("/list")
    public AjaxResult list(@RequestParam String queryDate,
                           @RequestParam(required = false)String tableSchema,
                           @RequestParam(defaultValue = "10") Integer limit) {
        List<DorisTableGrowthVO> list = dorisTableGrowthService.selectDorisTableGrowth(queryDate, tableSchema, limit);
        return AjaxResult.success(list);
    }
}
