package com.MetaApp.doris.domain;

import lombok.Data;

@Data
public class SlowLogVO {

    private String user;
    private String stmt;
    private String state;

    private Double cpuTimeMin;
    private Double queryTimeMin;
    private Double memoryMegabyte;

    private Double avgCpuTimeMin;
    private Double avgQueryTimeMin;
    private Double avgMemoryMegabyte;
    private Double avgCPUNum;

    private Integer useTimes;
}
