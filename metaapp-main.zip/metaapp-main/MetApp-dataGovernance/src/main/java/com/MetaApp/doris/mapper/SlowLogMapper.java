package com.MetaApp.doris.mapper;

import com.MetaApp.doris.domain.SlowLogVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
@Mapper
public interface SlowLogMapper {
    List<SlowLogVO> selectSlowLogList(@Param("user") String user,
                                      @Param("state") String state,
                                      @Param("startTime") String startTime,
                                      @Param("endTime") String endTime,
                                      @Param("limit") Integer limit);
}
