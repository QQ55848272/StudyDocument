package com.MetaApp.hdsp.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.hdsp.service.IExecutionLogService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hdsp/logs")
public class ExecutionLogController {

    private final IExecutionLogService executionLogService;

    public ExecutionLogController(IExecutionLogService executionLogService) {
        this.executionLogService = executionLogService;
    }

    /**
     * 查询日志接口
     * 示例：GET /meta/logs/query?execId=123&name=worker
     */
    @GetMapping("/query")
    public AjaxResult getExecutionLog(
            @RequestParam Long execId,
            @RequestParam String name) {
        String log = executionLogService.getExecutionLog(execId, name);
        return AjaxResult.success(log);
    }
}
