package com.MetaApp.metadata.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class TableNameTable {
    private String siteName;
    private String schemaName;
    private String tableName;
}
