package com.MetaApp.metadata.mapper;

import com.MetaApp.metadata.domain.DorisAllTableInfomation;

import java.util.List;

public interface DorisAllTableInfomationMapper {
    List<DorisAllTableInfomation> selectDorisTableList(DorisAllTableInfomation filter);
    List<String> selectAllSchemas();
}
