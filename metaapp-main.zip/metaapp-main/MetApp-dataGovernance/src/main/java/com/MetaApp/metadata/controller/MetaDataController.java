package com.MetaApp.metadata.controller;

import com.MetaApp.metadata.domain.SchemaTable;
import com.MetaApp.metadata.domain.SiteTable;
import com.MetaApp.metadata.domain.TableNameTable;
import com.MetaApp.metadata.service.MetaDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/metadata")//它是 Spring MVC 提供的一个注解，用于指定当前控制器类或方法的 URL 请求路径前缀。
public class MetaDataController {
    @Autowired
    private MetaDataService metaDataService;

    @GetMapping("/site")
    public List<SiteTable> site() {
        return metaDataService.getSiteMapper();
    }

    @GetMapping("/schema")
    public List<SchemaTable> schema() {
        return metaDataService.getSchemaMapper();
    }

    @GetMapping("/tableNames")
    public List<TableNameTable> tableNames() {
        return metaDataService.getTableNameMapper();
    }
}
