package com.MetaApp.doris.service;

import com.MetaApp.doris.domain.SlowLogDetailsVO;

import java.util.List;

public interface ISlowLogDetailsService {
    List<SlowLogDetailsVO> selectSlowLogList(String startTime,String endTime,String user,String state,String stmt);
}
