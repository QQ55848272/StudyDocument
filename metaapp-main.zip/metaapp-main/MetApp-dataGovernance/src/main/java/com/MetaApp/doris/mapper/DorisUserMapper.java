package com.MetaApp.doris.mapper;

import com.MetaApp.doris.domain.DorisUserVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
@Mapper
public interface DorisUserMapper {
    @Select("select DISTINCT user  as username from doris_audit_db__.doris_slow_log_tbl__")
    List<DorisUserVO> selectAllUsers();
}
