package com.MetaApp.metadata.mapper;

import com.MetaApp.metadata.domain.DorisAllTableInfomation;
import com.MetaApp.metadata.domain.DorisTableSelect;

import java.util.List;

public interface DorisTableSelectMapper {
    List<DorisTableSelect> selectDorisTableList(DorisTableSelect filter);
    List<String> selectAllSchemas();
}
