package com.MetaApp.hdsp.service.impl;

import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.hdsp.domain.ExecutionLog;
import com.MetaApp.hdsp.mapper.ExecutionLogMapper;
import com.MetaApp.hdsp.service.IExecutionLogService;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;


@Service
public class ExecutionLogServiceImpl implements IExecutionLogService {

    private final ExecutionLogMapper executionLogMapper;

    public ExecutionLogServiceImpl(ExecutionLogMapper executionLogMapper) {
        this.executionLogMapper = executionLogMapper;
    }

    @Override
    @DataSource(value = DataSourceType.HDSP)
    public String getExecutionLog(Long execId, String name) {
        List<ExecutionLog> logs = executionLogMapper.selectExecutionLog(execId, name);

        if (logs == null || logs.isEmpty()) {
            return "未找到日志";
        }

        // 1. 拼接所有日志 byte[]
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        for (ExecutionLog log : logs) {
            if (log.getLog() != null) {
                try {
                    baos.write(log.getLog());
                } catch (Exception e) {
                    // ignore
                }
            }
        }

        byte[] logBytes = baos.toByteArray();

        // 尝试直接读取为 UTF-8 文本
        try {
            String content = new String(logBytes, StandardCharsets.UTF_8);
            if (isReadableText(content)) {
                return content;
            }
        } catch (Exception ignored) { }

        // 尝试 GZIP 解压
        try (GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(logBytes))) {
            byte[] decompressed = toByteArray(gzip);
            return new String(decompressed, StandardCharsets.UTF_8);
        } catch (Exception ignored) { }

        // 尝试 ZLIB 解压
        try (InflaterInputStream inflater = new InflaterInputStream(new ByteArrayInputStream(logBytes))) {
            byte[] decompressed = toByteArray(inflater);
            return new String(decompressed, StandardCharsets.UTF_8);
        } catch (Exception ignored) { }

        return "日志内容为二进制或未知压缩格式，无法直接解析";
    }

    /**
     * 读取输入流为 byte[]（JDK8兼容）
     */
    private static byte[] toByteArray(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int n;
        while ((n = in.read(buffer)) != -1) {
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    /**
     * 判断文本是否为可读文本（过滤二进制内容）
     */
    private boolean isReadableText(String content) {
        long controlChars = content.chars().filter(ch -> ch < 32 && ch != 9 && ch != 10 && ch != 13).count();
        return controlChars < content.length() * 0.05; // 控制字符比例低于 5%
    }
}