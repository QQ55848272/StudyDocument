package com.MetaApp.hdsp.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class HdspMonitorTaskAlarmVO {
    private Long execId;
    private String workflowName;
    private String jobId;
    private String workflowDescription;
    private String jobName;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date startTimestamp;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date endTimestamp;
    private Double useTime;
    private String createBy;
    private String jobDescription;
    private String handleFlag;
    private String solveFlag;
    private String alarmReasion;
    private String errorType;
}