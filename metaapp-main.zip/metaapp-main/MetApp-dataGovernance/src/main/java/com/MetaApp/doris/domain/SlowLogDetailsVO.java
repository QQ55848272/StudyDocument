package com.MetaApp.doris.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class SlowLogDetailsVO {
    private String time;
    private String user;
    private String clientIp;
    private String stmt;
    private String state;
    private String errorMessage;
    private Long scanRows;
    private Long returnRows;
    private Double cpuTimeMin;
    private Double queryTimeMin;
    private Double memoryMegabyte;
    private Double cpuNum;
}
