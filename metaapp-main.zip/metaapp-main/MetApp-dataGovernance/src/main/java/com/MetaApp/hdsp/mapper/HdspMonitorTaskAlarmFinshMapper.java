package com.MetaApp.hdsp.mapper;

import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmFinsh;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface HdspMonitorTaskAlarmFinshMapper {

    /**
     * 新增告警
     */
    int insertAlarm(HdspMonitorTaskAlarmFinsh alarm);
}