package com.MetaApp.metadata.service.impl;

import com.MetaApp.metadata.domain.DorisTableColumnDetails;
import com.MetaApp.metadata.mapper.DorisTableColumnDetailsMapper;
import com.MetaApp.metadata.service.DorisTableColumnDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
@Service
public class DorisTableColumnDetailsServiceImpl implements DorisTableColumnDetailsService {
    @Autowired
    private DorisTableColumnDetailsMapper mapper;
    @Override
    public List<DorisTableColumnDetails> selectColumnList(DorisTableColumnDetails filter) {
        return mapper.getDorisTableColumnDetails(filter);
    }
}
