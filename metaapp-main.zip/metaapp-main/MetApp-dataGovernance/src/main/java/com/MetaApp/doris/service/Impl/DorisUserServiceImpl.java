package com.MetaApp.doris.service.Impl;

import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.doris.domain.DorisUserVO;
import com.MetaApp.doris.mapper.DorisUserMapper;
import com.MetaApp.doris.service.IDorisUserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
@Service
public class DorisUserServiceImpl implements IDorisUserService {
    @Resource
    private DorisUserMapper dorisUserMapper;
    @DataSource(value = DataSourceType.SLAVE)
    @Override
    public List<DorisUserVO> getDorisUsers() {
        return dorisUserMapper.selectAllUsers();
    }
}
