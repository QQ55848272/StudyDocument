package com.MetaApp.doris.service;

import com.MetaApp.doris.domain.SlowLogVO;

import java.util.List;

public interface SlowLogService {
    List<SlowLogVO> selectSlowLogList(String user, String state, String startTime, String endTime, Integer limit);
}
