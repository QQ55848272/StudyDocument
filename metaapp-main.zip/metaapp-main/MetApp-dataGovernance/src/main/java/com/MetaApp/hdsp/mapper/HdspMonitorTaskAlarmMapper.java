package com.MetaApp.hdsp.mapper;

import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmVO;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;


@Mapper
public interface HdspMonitorTaskAlarmMapper {

    @Select("<script>" +
            "WITH hdsp AS (" +
            "    SELECT " +
            "        a.exec_id, " +
            "        a.workflow_name, " +
            "        a.job_id, " +
            "        a.workflow_description, " +
            "        a.job_name, " +
            "        a.start_timestamp, " +
            "        a.end_timestamp, " +
            "        a.use_time, " +
            "        c.real_name AS create_by, " +
            "        b.job_description, " +
            "        IF(d.exec_id IS NULL, '未处理', '已处理') AS handle_flag, " +
            "        d.solve_flag ,d.alarm_reasion,d.error_type" +
            "    FROM test.hdsp_monitor_task_alarm a " +
            "    LEFT JOIN test.test_hdsp_xdis_dispatch_job b ON a.job_name = b.job_name " +
            "    LEFT JOIN test.hdsp_monitor_task_user_mapping c ON b.job_name = c.job_name " +
            "    LEFT JOIN test.hdsp_monitor_task_alarm_finsh d " +
            "        ON a.exec_id = d.exec_id " +
            "        AND a.workflow_name = d.workflow_name " +
            "        AND a.job_name = d.job_name" +
            ") " +
            "SELECT " +
            "    exec_id AS execId, " +
            "    workflow_name AS workflowName, " +
            "    job_id AS jobId, " +
            "    workflow_description AS workflowDescription, " +
            "    job_name AS jobName, " +
            "    start_timestamp AS startTimestamp, " +
            "    end_timestamp AS endTimestamp, " +
            "    use_time AS useTime, " +
            "    create_by AS createBy, " +
            "    job_description AS jobDescription, " +
            "    handle_flag AS handleFlag, " +
            "    solve_flag AS solveFlag, " +
            "    alarm_reasion AS alarmReasion, " +
            "    error_type AS errorType " +
            "FROM hdsp " +
            "<where>" +
            "    <if test='execId != null and execId != \"\"'> AND exec_id = #{execId} </if>" +
            "    <if test='workflowName != null and workflowName != \"\"'> AND workflow_name = #{workflowName} </if>" +
            "    <if test='jobName != null and jobName != \"\"'> AND job_name = #{jobName} </if>" +
            "    <if test='realName != null and realName != \"\"'> AND create_by = #{realName} </if>" +
            "    <if test='startTime != null'> AND start_timestamp &gt;= #{startTime} </if>" +
            "    <if test='endTime != null'> AND start_timestamp &lt;= #{endTime} </if>" +
            "    <if test='handleFlag != null and handleFlag != \"\"'> AND handle_flag = #{handleFlag} </if>" +
            "    <if test='solveFlag != null and solveFlag != \"\"'> AND solve_flag = #{solveFlag} </if>" +
            "    <if test='errorType != null and errorType != \"\"'> AND error_type = #{errorType} </if>" +
            "</where>" +
            "ORDER BY start_timestamp DESC" +
            "</script>")
    List<HdspMonitorTaskAlarmVO> selectTaskAlarmList(
            @Param("execId") Long execId,
            @Param("workflowName") String workflowName,
            @Param("jobName") String jobName,
            @Param("realName") String realName,
            @Param("startTime") Date startTime,
            @Param("endTime") Date endTime,
            @Param("handleFlag") String handleFlag,
            @Param("solveFlag") String solveFlag,
            @Param("errorType") String errorType
    );
}
