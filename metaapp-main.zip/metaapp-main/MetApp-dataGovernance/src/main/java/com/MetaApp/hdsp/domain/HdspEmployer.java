package com.MetaApp.hdsp.domain;

import lombok.Data;

@Data
public class HdspEmployer {
    private String createBy;
}
