package com.MetaApp.hdsp.service;


import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmVO;

import java.util.Date;
import java.util.List;

public interface IHdspMonitorTaskAlarmService {
    List<HdspMonitorTaskAlarmVO> selectTaskAlarmList(
            Long execId,
            String workflowName,
            String jobName,
            String realName,
            Date startTime,
            Date endTime,
            String handleFlag,
            String solveFlag,
            String errorType
    );
}
