package com.MetaApp.hdsp.domain;

import lombok.Data;

import java.io.Serializable;
@Data
public class ExecutionLog implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 执行ID */
    private Long execId;

    /** 名称 */
    private String name;

    /** 日志内容（longblob） */
    private byte[] log;
}
