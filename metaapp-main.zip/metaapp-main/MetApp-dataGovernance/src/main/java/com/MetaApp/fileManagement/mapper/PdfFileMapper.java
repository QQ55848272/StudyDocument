package com.MetaApp.fileManagement.mapper;

import com.MetaApp.fileManagement.domain.PdfFile;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
@Mapper
public interface PdfFileMapper {
    int insert(PdfFile pdfFile);
    List<PdfFile> selectByKeyword(@Param("keyword") String keyword);
    PdfFile selectById(@Param("id") Long id);
}
