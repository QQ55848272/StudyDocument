package com.MetaApp.metadata.service;

import com.MetaApp.metadata.domain.DorisTableColumnDetails;

import java.util.List;

public interface DorisTableColumnDetailsService {
    List<DorisTableColumnDetails> selectColumnList(DorisTableColumnDetails filter);
}
