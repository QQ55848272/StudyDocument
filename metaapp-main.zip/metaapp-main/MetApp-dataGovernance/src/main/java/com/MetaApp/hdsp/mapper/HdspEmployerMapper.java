package com.MetaApp.hdsp.mapper;

import com.MetaApp.hdsp.domain.HdspEmployer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface HdspEmployerMapper {
    @Select("select DISTINCT b.real_name as createBy from test.test_hdsp_xdis_dispatch_job a inner JOIN test.test_hdsp_iam_user b ON a.last_updated_by = b.id")
    List<HdspEmployer> selectEmployers();
}
