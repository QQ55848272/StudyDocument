package com.MetaApp.doris.mapper;

import com.MetaApp.doris.domain.DorisTableGrowthVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
@Mapper
public interface DorisTableGrowthMapper {

    List<DorisTableGrowthVO> selectDorisTableGrowth(@Param("queryDate") String queryDate,
                                                    @Param("tableSchema") String tableSchema,
                                                    @Param("limit") Integer limit);
}
