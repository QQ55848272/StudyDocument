package com.MetaApp.doris.mapper;

import com.MetaApp.doris.domain.SlowLogDetailsVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SlowLogDetailsMapper {
    List<SlowLogDetailsVO> selectSlowLogList(
            @Param("startTime")String startTime,
            @Param("endTime") String endTime,
            @Param("user")String user,
            @Param("state")String state,
            @Param("stmt")String stmt);
}
