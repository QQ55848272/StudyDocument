package com.MetaApp.hdsp.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class HdspMonitorTaskAlarmFinsh {

    private Long execId;

    private String workflowName;

    private String jobName;

    private String alarmReasion;

    private String errorType;

    private String solveFlag;

    private String createBy;

}