package com.MetaApp.dataGovernance.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.MetaApp.common.annotation.Excel;
import com.MetaApp.common.core.domain.BaseEntity;

/**
 * schema下包含信息对象 schema_tables_detailes
 * 
 * @author meta
 * @date 2025-04-13
 */
public class SchemaTablesDetailes extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    private Long id;

    /** 厂别 */
    @Excel(name = "厂别")
    private String site;

    /** 用户名 */
    @Excel(name = "用户名")
    private String dataSchema;

    /** 厂内机种 */
    @Excel(name = "厂内机种")
    private String model;

    /** 数据源 */
    @Excel(name = "数据源")
    private String dataSource;

    /** 客户机种 */
    @Excel(name = "客户机种")
    private String customerModel;

    /** 表名 */
    @Excel(name = "表名")
    private String tableName;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setSite(String site) 
    {
        this.site = site;
    }

    public String getSite() 
    {
        return site;
    }
    public void setDataSchema(String dataSchema) 
    {
        this.dataSchema = dataSchema;
    }

    public String getDataSchema() 
    {
        return dataSchema;
    }
    public void setModel(String model) 
    {
        this.model = model;
    }

    public String getModel() 
    {
        return model;
    }
    public void setDataSource(String dataSource) 
    {
        this.dataSource = dataSource;
    }

    public String getDataSource() 
    {
        return dataSource;
    }
    public void setCustomerModel(String customerModel) 
    {
        this.customerModel = customerModel;
    }

    public String getCustomerModel() 
    {
        return customerModel;
    }
    public void setTableName(String tableName) 
    {
        this.tableName = tableName;
    }

    public String getTableName() 
    {
        return tableName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("site", getSite())
            .append("dataSchema", getDataSchema())
            .append("model", getModel())
            .append("dataSource", getDataSource())
            .append("customerModel", getCustomerModel())
            .append("tableName", getTableName())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .toString();
    }
}
