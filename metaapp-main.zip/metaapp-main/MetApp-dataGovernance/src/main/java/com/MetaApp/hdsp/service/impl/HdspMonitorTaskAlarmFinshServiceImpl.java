package com.MetaApp.hdsp.service.impl;

import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmFinsh;
import com.MetaApp.hdsp.mapper.HdspMonitorTaskAlarmFinshMapper;
import com.MetaApp.hdsp.service.IHdspMonitorTaskAlarmFinshService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HdspMonitorTaskAlarmFinshServiceImpl implements IHdspMonitorTaskAlarmFinshService {

    @Autowired
    private HdspMonitorTaskAlarmFinshMapper alarmMapper;
    @DataSource(value = DataSourceType.SLAVE)
    @Override
    public int insertAlarm(HdspMonitorTaskAlarmFinsh alarm) {
        if (alarm.getCreateBy() == null) {
            alarm.setCreateBy("system");
        }
        return alarmMapper.insertAlarm(alarm);
    }
}
