package com.MetaApp.doris.service.Impl;

import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.doris.domain.SlowLogVO;
import com.MetaApp.doris.mapper.SlowLogMapper;
import com.MetaApp.doris.service.SlowLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SlowLogServiceImpl implements SlowLogService {

    @Autowired
    private SlowLogMapper slowLogMapper;

    @Override
    @DataSource(value = DataSourceType.SLAVE)
    public List<SlowLogVO> selectSlowLogList(String user, String state, String startTime, String endTime, Integer limit) {
        return slowLogMapper.selectSlowLogList(user, state, startTime, endTime, limit);
    }
}
