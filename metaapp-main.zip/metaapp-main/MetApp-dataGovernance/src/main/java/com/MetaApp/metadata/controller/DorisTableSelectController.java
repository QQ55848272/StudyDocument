package com.MetaApp.metadata.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.metadata.domain.DorisAllTableInfomation;
import com.MetaApp.metadata.domain.DorisTableSelect;
import com.MetaApp.metadata.service.DorisTableSelectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/metadata")
public class DorisTableSelectController {
    @Autowired
    private DorisTableSelectService dorisTableSelectService;

    @GetMapping("/tableList")
    public AjaxResult tableList(DorisTableSelect filter) {
        List<DorisTableSelect> list = dorisTableSelectService.selectDorisTableList(filter);
        return AjaxResult.success(list);
    }

    @GetMapping("/table_schemas")
    public AjaxResult getSchemas() {
        return AjaxResult.success(dorisTableSelectService.selectAllSchemas());
    }
}
