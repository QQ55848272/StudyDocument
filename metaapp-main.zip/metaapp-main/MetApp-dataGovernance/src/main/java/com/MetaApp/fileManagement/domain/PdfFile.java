package com.MetaApp.fileManagement.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PdfFile {
    private Long id;
    private String filename;
    private String category;
    private String filepath;
    private LocalDateTime uploadTime;
}
