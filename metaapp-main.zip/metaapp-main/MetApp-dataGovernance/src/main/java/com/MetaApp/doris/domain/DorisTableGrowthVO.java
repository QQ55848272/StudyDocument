package com.MetaApp.doris.domain;

import lombok.Data;

import java.util.Date;

@Data
public class DorisTableGrowthVO {

    private String dbDate;
    private String tableSchema;
    private String tableName;
    private Double dataLengthI1;
    private Double tableRowsI1;
    private String tableComment;
    private Double dataLengthI0;
    private Double tableRowsI0;
    private Double dataLength0;
    private Double avgDataLength;
    private String createTime;
    private String updateTime;
    private String tableType;
    private String flag1;
    private String flag2;

}
