package com.MetaApp.metadata.service;

import com.MetaApp.metadata.domain.DorisAllTableInfomation;

import java.util.List;

public interface DorisAllTableInfomationService {
    List<DorisAllTableInfomation> selectDorisTableList(DorisAllTableInfomation filter);
    List<String> selectAllSchemas();
}
