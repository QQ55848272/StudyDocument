package com.MetaApp.metadata.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.metadata.domain.DorisTableColumnDetails;
import com.MetaApp.metadata.service.DorisTableColumnDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/metadata")
public class DorisTableColumnDetailsController {
    @Autowired
    private DorisTableColumnDetailsService dorisTableColumnDetailsService;

    @GetMapping("/columnList")
    public AjaxResult columnList(DorisTableColumnDetails filter) {
        List<DorisTableColumnDetails> list = dorisTableColumnDetailsService.selectColumnList(filter);
        return AjaxResult.success(list);
    }
}
