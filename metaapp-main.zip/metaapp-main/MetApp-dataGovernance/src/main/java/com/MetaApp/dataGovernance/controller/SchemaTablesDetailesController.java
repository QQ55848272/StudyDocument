package com.MetaApp.dataGovernance.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.MetaApp.common.annotation.Log;
import com.MetaApp.common.core.controller.BaseController;
import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.common.enums.BusinessType;
import com.MetaApp.dataGovernance.domain.SchemaTablesDetailes;
import com.MetaApp.dataGovernance.service.ISchemaTablesDetailesService;
import com.MetaApp.common.utils.poi.ExcelUtil;
import com.MetaApp.common.core.page.TableDataInfo;

/**
 * schema下包含信息Controller
 * 
 * @author meta
 * @date 2025-04-13
 */
@RestController
@RequestMapping("/dataGovernance/dataGovernance")
public class SchemaTablesDetailesController extends BaseController
{
    @Autowired
    private ISchemaTablesDetailesService schemaTablesDetailesService;

    /**
     * 查询schema下包含信息列表
     */
    @PreAuthorize("@ss.hasPermi('dataGovernance:dataGovernance:list')")
    @GetMapping("/list")
    public TableDataInfo list(SchemaTablesDetailes schemaTablesDetailes)
    {
        startPage();
        List<SchemaTablesDetailes> list = schemaTablesDetailesService.selectSchemaTablesDetailesList(schemaTablesDetailes);
        return getDataTable(list);
    }

    /**
     * 导出schema下包含信息列表
     */
    @PreAuthorize("@ss.hasPermi('dataGovernance:dataGovernance:export')")
    @Log(title = "schema下包含信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, SchemaTablesDetailes schemaTablesDetailes)
    {
        List<SchemaTablesDetailes> list = schemaTablesDetailesService.selectSchemaTablesDetailesList(schemaTablesDetailes);
        ExcelUtil<SchemaTablesDetailes> util = new ExcelUtil<SchemaTablesDetailes>(SchemaTablesDetailes.class);
        util.exportExcel(response, list, "schema下包含信息数据");
    }

    /**
     * 获取schema下包含信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('dataGovernance:dataGovernance:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(schemaTablesDetailesService.selectSchemaTablesDetailesById(id));
    }

    /**
     * 新增schema下包含信息
     */
    @PreAuthorize("@ss.hasPermi('dataGovernance:dataGovernance:add')")
    @Log(title = "schema下包含信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SchemaTablesDetailes schemaTablesDetailes)
    {
        return toAjax(schemaTablesDetailesService.insertSchemaTablesDetailes(schemaTablesDetailes));
    }

    /**
     * 修改schema下包含信息
     */
    @PreAuthorize("@ss.hasPermi('dataGovernance:dataGovernance:edit')")
    @Log(title = "schema下包含信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SchemaTablesDetailes schemaTablesDetailes)
    {
        return toAjax(schemaTablesDetailesService.updateSchemaTablesDetailes(schemaTablesDetailes));
    }

    /**
     * 删除schema下包含信息
     */
    @PreAuthorize("@ss.hasPermi('dataGovernance:dataGovernance:remove')")
    @Log(title = "schema下包含信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(schemaTablesDetailesService.deleteSchemaTablesDetailesByIds(ids));
    }
}
