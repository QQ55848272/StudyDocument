package com.MetaApp.hdsp.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmFinsh;
import com.MetaApp.hdsp.service.IHdspMonitorTaskAlarmFinshService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hdsp/taskAlarm")
public class HdspMonitorTaskAlarmFinshController {

    @Autowired
    private IHdspMonitorTaskAlarmFinshService alarmService;

    /**
     * 新增告警
     */
    @PostMapping("/add")
    public AjaxResult addAlarm(@RequestBody HdspMonitorTaskAlarmFinsh alarm) {
        int result = alarmService.insertAlarm(alarm);
        return result > 0 ? AjaxResult.success("新增成功") : AjaxResult.error("新增失败");
    }
}
