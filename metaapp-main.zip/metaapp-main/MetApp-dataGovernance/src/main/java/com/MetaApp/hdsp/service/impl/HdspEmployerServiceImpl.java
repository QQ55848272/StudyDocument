package com.MetaApp.hdsp.service.impl;

import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.hdsp.domain.HdspEmployer;
import com.MetaApp.hdsp.mapper.HdspEmployerMapper;
import com.MetaApp.hdsp.service.IHdspEmployerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class HdspEmployerServiceImpl implements IHdspEmployerService {
    @Autowired
    private HdspEmployerMapper hdspEmployerMapper;

    @Override
    @DataSource(value = DataSourceType.SLAVE)
    public List<HdspEmployer> getAllEmployers() {
        return hdspEmployerMapper.selectEmployers();
    }
}
