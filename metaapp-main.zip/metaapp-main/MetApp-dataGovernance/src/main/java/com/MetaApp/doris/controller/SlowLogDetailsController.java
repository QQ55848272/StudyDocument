package com.MetaApp.doris.controller;

import com.MetaApp.common.core.controller.BaseController;
import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.common.core.page.TableDataInfo;
import com.MetaApp.doris.domain.SlowLogDetailsVO;
import com.MetaApp.doris.service.ISlowLogDetailsService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/doris/slowSql")
public class SlowLogDetailsController extends BaseController {
    @Resource
    private ISlowLogDetailsService slowLogService;

    @GetMapping("/details")
    public AjaxResult list(
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endTime,
            @RequestParam(required = false) String user,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String stmt,
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize
    ) {
        PageHelper.startPage(pageNum, pageSize);
        List<SlowLogDetailsVO> slowLogDetailsVOS = slowLogService.selectSlowLogList(startTime, endTime, user, state, stmt);
        PageInfo<SlowLogDetailsVO> slowLogDetailsVOPageInfo = new PageInfo<>(slowLogDetailsVOS);
        return AjaxResult.success(slowLogDetailsVOPageInfo);
    }
}

