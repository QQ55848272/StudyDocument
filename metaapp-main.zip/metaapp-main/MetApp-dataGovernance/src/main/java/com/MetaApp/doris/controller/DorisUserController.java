package com.MetaApp.doris.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.doris.domain.DorisUserVO;
import com.MetaApp.doris.service.IDorisUserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/doris/user")
public class DorisUserController {

    private final IDorisUserService dorisUserService;

    public DorisUserController(IDorisUserService dorisUserService) {
        this.dorisUserService = dorisUserService;
    }
    @GetMapping("/list")
    public AjaxResult getDorisUser() {
        List<DorisUserVO> dorisUsers = dorisUserService.getDorisUsers();
        return AjaxResult.success(dorisUsers);
    }
}
