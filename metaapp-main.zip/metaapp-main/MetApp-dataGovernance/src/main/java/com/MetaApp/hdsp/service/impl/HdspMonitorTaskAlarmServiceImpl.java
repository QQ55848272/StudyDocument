package com.MetaApp.hdsp.service.impl;


import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmVO;
import com.MetaApp.hdsp.mapper.HdspMonitorTaskAlarmMapper;
import com.MetaApp.hdsp.service.IHdspMonitorTaskAlarmService;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class HdspMonitorTaskAlarmServiceImpl implements IHdspMonitorTaskAlarmService {

    @Resource
    private HdspMonitorTaskAlarmMapper taskAlarmMapper;
    @DataSource(value = DataSourceType.SLAVE)
    @Override
    public List<HdspMonitorTaskAlarmVO> selectTaskAlarmList(
            Long execId,
            String workflowName,
            String jobName,
            String realName,
            Date startTime,
            Date endTime,
            String handleFlag,
            String solveFlag,
            String errorType) {
        return taskAlarmMapper.selectTaskAlarmList(execId, workflowName, jobName, realName, startTime, endTime,handleFlag,solveFlag,errorType);
    }
}
