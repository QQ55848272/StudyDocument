package com.MetaApp.doris.service;

import com.MetaApp.doris.domain.DorisTableGrowthVO;

import java.util.List;

public interface IDorisTableGrowthService {
    List<DorisTableGrowthVO> selectDorisTableGrowth(String queryDate, String tableSchema, Integer limit);
}