package com.MetaApp.doris.service;

import com.MetaApp.doris.domain.DorisUserVO;

import java.util.List;

public interface IDorisUserService {
    List<DorisUserVO> getDorisUsers();
}
