package com.MetaApp.metadata.service.impl;

import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class TaskDescriptionServiceImpl {
    public  String generateTaskDescription(
            String tableName,//表名
            String dorisDb,//DB名称
            String owner,//用户
            String ticketId,//需求单号
            String columnComment,//字段描述
            String columnName,//字段名称
            String synchronousMode,    //同步方式
            String syncFrequency  //频率
    ) {
        String createdDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd"));
        return String.format(
                "        任务名称"+
                        "任务描述：%s\n" +
                        "doris: %s  \n" +
                        "责任人：柳坤 \n" +
                        "用户：meta项目/需求人：%s 需求单号:%s\n" +
                        "创建日期：%s\n" +
                        "主题名称:按照 %s %s同步 频率：%s\n" +
                        "层次名称：%s",
                tableName, dorisDb, owner, ticketId, createdDate, columnComment,columnName,synchronousMode, syncFrequency, dorisDb
        );
    }
}
