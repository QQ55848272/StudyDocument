package com.MetaApp.metadata.controller;

import com.MetaApp.metadata.service.impl.TaskDescriptionServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/metadata")
public class TaskDescriptionController {
    @Autowired
    private TaskDescriptionServiceImpl taskDescriptionService;
    @GetMapping("/task_description")
    public String taskDescription(String tableName,//表名
                                  String dorisDb,//DB名称
                                  String owner,//用户
                                  String ticketId,//需求单号
                                  String columnComment,//字段描述
                                  String columnName,//字段名称
                                  String synchronousMode,    //同步方式
                                  String syncFrequency ) {
        return taskDescriptionService.generateTaskDescription(
                tableName,
                dorisDb,//DB名称
                owner,//用户
                ticketId,//需求单号
                columnComment,//字段描述
                columnName,//字段名称
                synchronousMode, //同步方式
                syncFrequency );
    }
}
