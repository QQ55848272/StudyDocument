package com.MetaApp.hdsp.service;

import com.MetaApp.hdsp.domain.HdspEmployer;

import java.util.List;

public interface IHdspEmployerService {
    List<HdspEmployer> getAllEmployers();
}
