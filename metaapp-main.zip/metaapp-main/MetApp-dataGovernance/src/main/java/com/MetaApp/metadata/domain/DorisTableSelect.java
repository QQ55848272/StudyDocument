package com.MetaApp.metadata.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class DorisTableSelect {
    private String tableSchema;
    private String tableName;
    private String tableType;
    private String columnDescription;
    private String tableDescription;
    private String tableComment;
}
