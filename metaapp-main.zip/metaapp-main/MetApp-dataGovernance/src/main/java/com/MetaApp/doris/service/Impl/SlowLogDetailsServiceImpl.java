package com.MetaApp.doris.service.Impl;

import com.MetaApp.common.annotation.DataSource;
import com.MetaApp.common.enums.DataSourceType;
import com.MetaApp.doris.domain.SlowLogDetailsVO;
import com.MetaApp.doris.mapper.SlowLogDetailsMapper;
import com.MetaApp.doris.service.ISlowLogDetailsService;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.List;
@Service
public class SlowLogDetailsServiceImpl implements ISlowLogDetailsService {
    @Resource
    private SlowLogDetailsMapper slowLogDetailsMapper;
    @Override
    @DataSource(value = DataSourceType.SLAVE)
    public List<SlowLogDetailsVO> selectSlowLogList(String startTime,String endTime,String user,String state,String stmt) {
        return slowLogDetailsMapper.selectSlowLogList(startTime,endTime,user,state,stmt);
    }
}
