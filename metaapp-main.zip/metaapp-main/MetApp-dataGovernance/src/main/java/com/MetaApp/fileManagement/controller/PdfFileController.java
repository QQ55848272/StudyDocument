package com.MetaApp.fileManagement.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.common.utils.StringUtils;
import com.MetaApp.common.utils.uuid.UUID;
import com.MetaApp.fileManagement.domain.PdfFile;
import com.MetaApp.fileManagement.mapper.PdfFileMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/files")
public class PdfFileController {

    @Value("${file.upload-path:D:\\uploads}")
    private String uploadPath;

    @Autowired
    private PdfFileMapper pdfFileMapper;

    @PostMapping("/upload")
    public AjaxResult upload(@RequestParam("file") MultipartFile file,
                             @RequestParam("filename") String filename,
                             @RequestParam("category") String category) throws IOException {
        String uuidName = UUID.randomUUID() + "-" + file.getOriginalFilename();
        File saveFile = new File(uploadPath, uuidName);
        if (!saveFile.getParentFile().exists()) saveFile.getParentFile().mkdirs();
        file.transferTo(saveFile);

        PdfFile pdf = new PdfFile();
        pdf.setFilename(filename);
        pdf.setCategory(category);
        pdf.setFilepath(uuidName); // 只存文件名！
        pdf.setUploadTime(LocalDateTime.now());
        pdfFileMapper.insert(pdf);

        return AjaxResult.success("上传成功");
    }

    @GetMapping("/view/{filename}")
    public void viewFile(@PathVariable String filename, HttpServletResponse response) throws IOException {
        File file = new File(uploadPath, filename);
        if (!file.exists()) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        // 依据文件后缀设置Content-Type
        String contentType = "application/octet-stream"; // 默认
        if (filename.endsWith(".pdf")) {
            contentType = "application/pdf";
        } else if (filename.endsWith(".xlsx")) {
            contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        } else if (filename.endsWith(".xls")) {
            contentType = "application/vnd.ms-excel";
        } else if (filename.endsWith(".docx")) {
            contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        } else if (filename.endsWith(".txt")) {
            contentType = "text/plain";
        } else if (filename.endsWith(".md") || filename.endsWith(".markdown")) {
            contentType = "text/markdown";
        }

        response.setContentType(contentType);
        response.setHeader("Content-Disposition", "inline; filename=" + URLEncoder.encode(filename, "UTF-8"));
        response.setHeader("Access-Control-Allow-Origin", "*");

        Files.copy(file.toPath(), response.getOutputStream());
    }


    @GetMapping("/list")
    public AjaxResult list(
            @RequestParam(value = "keyword", required = false) String keyword) {
        List<PdfFile> list = pdfFileMapper.selectByKeyword(keyword);
        return AjaxResult.success(list);
    }
}
