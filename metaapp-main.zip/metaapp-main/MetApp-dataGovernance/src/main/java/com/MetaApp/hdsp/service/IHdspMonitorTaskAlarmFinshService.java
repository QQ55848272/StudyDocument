package com.MetaApp.hdsp.service;

import com.MetaApp.hdsp.domain.HdspMonitorTaskAlarmFinsh;

public interface IHdspMonitorTaskAlarmFinshService {

    int insertAlarm(HdspMonitorTaskAlarmFinsh alarm);
}
