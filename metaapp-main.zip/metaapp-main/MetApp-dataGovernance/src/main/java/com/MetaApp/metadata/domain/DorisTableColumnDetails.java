package com.MetaApp.metadata.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DorisTableColumnDetails {
    private String tableSchema;
    private String tableName;
    private String columnName;
    private String columnType;
    private String isNullable;
    private String columnKey;
    private String columnComment;
}
