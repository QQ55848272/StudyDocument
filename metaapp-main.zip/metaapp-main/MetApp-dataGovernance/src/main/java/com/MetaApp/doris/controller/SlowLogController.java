package com.MetaApp.doris.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.common.core.page.TableDataInfo;
import com.MetaApp.doris.domain.SlowLogVO;
import com.MetaApp.doris.service.SlowLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.MetaApp.common.utils.PageUtils.startPage;

@RestController
@RequestMapping("/doris")
public class SlowLogController {

    @Autowired
    private SlowLogService slowLogService;

    @GetMapping("/slowSql/list")
    public AjaxResult list(
            @RequestParam(required = false) String user,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endTime,
            @RequestParam(required = false, defaultValue = "10") Integer limit
    ) {
        List<SlowLogVO> list = slowLogService.selectSlowLogList(user, state, startTime, endTime, limit);
        return AjaxResult.success(list);
    }
}
