package com.MetaApp.hdsp.mapper;

import com.MetaApp.hdsp.domain.ExecutionLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ExecutionLogMapper {

    /**
     * 根据 exec_id 和 name 模糊查询日志
     */
    @Select("SELECT exec_id, name, log FROM execution_logs WHERE exec_id = #{execId} AND name LIKE CONCAT('%', #{name}, '%') order by id")
    List<ExecutionLog> selectExecutionLog(@Param("execId") Long execId, @Param("name") String name);
}
