package com.MetaApp.hdsp.controller;

import com.MetaApp.common.core.domain.AjaxResult;
import com.MetaApp.hdsp.domain.HdspEmployer;
import com.MetaApp.hdsp.service.impl.HdspEmployerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/hdsp/employer")
public class HdspEmployerController {
    @Autowired
    private HdspEmployerServiceImpl hdspEmployerService;
    @GetMapping("/query")
    public AjaxResult getEmployerList(){
        List<HdspEmployer> allEmployers = hdspEmployerService.getAllEmployers();
        return AjaxResult.success(allEmployers);
    }

}
